import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.PreparedStatement;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
import java.sql.ResultSet;
//import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
/**
 * Servlet implementation class Connect
 */
@WebServlet("/nftDAO")
public class nftDAO 
{
	private static final long serialVersionUID = 1L;
	private Connection connect = null;
	private Statement statement = null;
	private PreparedStatement preparedStatement = null;
	private ResultSet resultSet = null;
	
	public nftDAO(){}
	
	/** 
	 * @see HttpServlet#HttpServlet()
     */
    protected void connect_func() throws SQLException {
    	//uses default connection to the database
        if (connect == null || connect.isClosed()) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                throw new SQLException(e);
            }
            connect = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/projectdb?allowPublicKeyRetrieval=true&useSSL=false&user=john&password=pass1234");
            System.out.println(connect);
        }
    }
    
    public boolean database_login(String email, String password) throws SQLException{
    	try {
    		connect_func("root","pass1234");
    		String sql = "select * from user where email = ?";
    		preparedStatement = connect.prepareStatement(sql);
    		preparedStatement.setString(1, email);
    		ResultSet rs = preparedStatement.executeQuery();
    		return rs.next();
    	}
    	catch(SQLException e) {
    		System.out.println("failed login");
    		return false;
    	}
    }
	//connect to the database 
    public void connect_func(String username, String password) throws SQLException {
        if (connect == null || connect.isClosed()) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                throw new SQLException(e);
            }
            connect = (Connection) DriverManager
  			      .getConnection("jdbc:mysql://127.0.0.1:3306/userdb?"
  			          + "useSSL=false&user=" + username + "&password=" + password);
            System.out.println(connect);
        }
    }
    
    public List<nft> listAllNfts() throws SQLException {
        List<nft> listNft = new ArrayList<nft>();        
        String sql = "SELECT * FROM nft";      
        connect_func();      
        statement = (Statement) connect.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);
         
        while (resultSet.next()) {
        	int id = resultSet.getInt("nftid");
            String name = resultSet.getString("nftname");
            String description = resultSet.getString("nftdescription");
            String image = resultSet.getString("imagePath");
            String userEmail = resultSet.getString("userEmail");
            
             
            nft nfts = new nft(id, name,description, image, userEmail);
            listNft.add(nfts);
        }        
        resultSet.close();
        disconnect();        
        return listNft;
    }
    
    protected void disconnect() throws SQLException {
        if (connect != null && !connect.isClosed()) {
        	connect.close();
        }
    }
    
    public void insert(nft nfts) throws SQLException {
    	connect_func("root","pass1234");         
		String sql = "insert into Nft(nftname, nftdescription, image, userEmail) values (?, ?, ?, ?)";
		preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
			preparedStatement.setString(1, nfts.getName());
			preparedStatement.setString(2, nfts.getDescription());
			preparedStatement.setString(3, nfts.getImage());
			preparedStatement.setString(4, nfts.getUserEmail());

		preparedStatement.executeUpdate();
        preparedStatement.close();
    }
    
    public boolean delete(String name) throws SQLException {
        String sql = "DELETE FROM Nft WHERE nftname = ?";        
        connect_func();
         
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, name);
         
        boolean rowDeleted = preparedStatement.executeUpdate() > 0;
        preparedStatement.close();
        return rowDeleted;     
    }
     
    public boolean update(nft nfts) throws SQLException {
        String sql = "update Nft set nftname=?, nftdescription =?,image = ?,userEmail=? where nftname = ?";
        connect_func();
        
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
		preparedStatement.setString(1, nfts.getName());
		preparedStatement.setString(2, nfts.getDescription());
		preparedStatement.setString(3, nfts.getImage());
		preparedStatement.setString(4, nfts.getUserEmail());
		
         
        boolean rowUpdated = preparedStatement.executeUpdate() > 0;
        preparedStatement.close();
        return rowUpdated;     
    }
    
    public nft getNft(String nftName) throws SQLException {
    	nft nft = null;
        String sql = "SELECT * FROM Nft WHERE nftname = ?";
         
        connect_func();
         
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, nftName);
         
        ResultSet resultSet = preparedStatement.executeQuery();
         
        if (resultSet.next()) {
            String name = resultSet.getString("nftname");
            String description = resultSet.getString("nftdescription");
            String image = resultSet.getString("imagePath");
            String userEmail = resultSet.getString("userEmail");          
            nft = new nft(name, description, image, userEmail);
        }
         
        resultSet.close();
        statement.close();
         
        return nft;
    }
    
    //TODO PROJECT1 PART2 CHECK TO MAKE SURE NAME ISNT ALREADY IN USE -> must be unique to be entered into table
    
    
    public void init() throws SQLException, FileNotFoundException, IOException{
    	connect_func();
        statement =  (Statement) connect.createStatement();
        
        String[] INITIAL = {"use projectdb; ",
					        "drop table if exists Nft; ",
					        ("CREATE TABLE if not exists Nft( " +
					            "nftid int auto_increment NOT NULL UNIQUE," + 
					            "nftname VARCHAR(30) NOT NULL UNIQUE, " +
					            "nftdescription VARCHAR(70) NOT NULL," +
					            "imagePath VARCHAR(250) NOT NULL," +
					            "userEmail VARCHAR(50) NOT NULL," +
					            "PRIMARY KEY (nftid) "+"); ")
        					};
        String[] TUPLES = {("insert into Nft(nftname, nftdescription, imagePath, userEmail)"+
        			"values ('dog', 'dog with an eyepatch', 'https://preview.redd.it/l4jzph3tc5z71.jpg?auto=webp&s=a89013de52f194e2bb2cdf95284cde222654c965', 'jeannette@gmail.com'),"
        			+ "		('eye', 'eyeball and stairs', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSouf5VBg6B0dsD_pzuhX3j4U42EozNN-eyhA&usqp=CAU', 'ashley@gmail.com'),"
        			+ "		('person', 'person drawn in paint', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSB7hRaz5q1seXRoxW-AN4Ptr0d-Ikdc9lquQ&usqp=CAU', 'jeannette@gmail.com'),"
        			+ "		('horses', 'multiple horse NFTs', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRrlBxUzPoJBBNgT15vC_z9iW3HirotMOgesQ&usqp=CAU', 'cody@gmail.com'),"
        			+ "		('pelicans', 'multiple pelican NFTs', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQouK6aSiMxxJa6IaDFFeSMAhYkyw7lzidphA&usqp=CAU', 'rudy@gmail.com'),"
        			+ "		('coin', 'crypto on a skyscraper', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSmGr0jVq6xiRcHgIXt8ACv1r7Ojx1VSVJNrQ&usqp=CAU', 'angelo@gmail.com'),"
        			+ "		('robot', 'robot standing', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQCE3l1dw0l3bYj_s6hKn-J2kvgCc9Mpto5yA&usqp=CAU', 'sophie@gmail.com'),"
        			+ "		('cat', 'fashionable cat', 'https://moon.ly/blog/content/images/2022/03/252.png', 'cody@gmail.com'),"
        			+ "		('clothed coin', 'coin with a hoodie', 'https://metav.rs/assets/uploads/2022/08/fake-NFTs.webp', 'steven@gmail.com'),"
        			+ "		('psychedelic cat', 'smoking cat with psychedelic background', 'https://miro.medium.com/max/1024/0*DFBQ7dyFQWRaOMkV.png', 'susie@gmail.com');")
			    			};
        
        //for loop to put these in database
        for (int i = 0; i < INITIAL.length; i++)
        	statement.execute(INITIAL[i]);
        for (int i = 0; i < TUPLES.length; i++)	
        	statement.execute(TUPLES[i]);
        disconnect();
    }
    
    
   
    
    
    
    
    
	
	

}
