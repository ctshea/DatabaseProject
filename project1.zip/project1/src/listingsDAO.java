import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.PreparedStatement;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
import java.sql.ResultSet;
//import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
/**
 * Servlet implementation class Connect
 */
@WebServlet("/listingsDAO")
public class listingsDAO 
{
	private static final long serialVersionUID = 1L;
	private Connection connect = null;
	private Statement statement = null;
	private PreparedStatement preparedStatement = null;
	private ResultSet resultSet = null;
	
	public listingsDAO(){}
	
	/** 
	 * @see HttpServlet#HttpServlet()
     */
    protected void connect_func() throws SQLException {
    	//uses default connection to the database
        if (connect == null || connect.isClosed()) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                throw new SQLException(e);
            }
            connect = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/projectdb?allowPublicKeyRetrieval=true&useSSL=false&user=john&password=pass1234");
            System.out.println(connect);
        }
    }
    
    public boolean database_login(String email, String password) throws SQLException{
    	try {
    		connect_func("root","pass1234");
    		String sql = "select * from user where email = ?";
    		preparedStatement = connect.prepareStatement(sql);
    		preparedStatement.setString(1, email);
    		ResultSet rs = preparedStatement.executeQuery();
    		return rs.next();
    	}
    	catch(SQLException e) {
    		System.out.println("failed login");
    		return false;
    	}
    }
	//connect to the database 
    public void connect_func(String username, String password) throws SQLException {
        if (connect == null || connect.isClosed()) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                throw new SQLException(e);
            }
            connect = (Connection) DriverManager
  			      .getConnection("jdbc:mysql://127.0.0.1:3306/userdb?"
  			          + "useSSL=false&user=" + username + "&password=" + password);
            System.out.println(connect);
        }
    }
    
    public List<listings> listAllListings() throws SQLException {
        List<listings> listListings = new ArrayList<listings>();        
        String sql = "SELECT * FROM Listings";      
        connect_func();      
        statement = (Statement) connect.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);
         
        while (resultSet.next()) {
        	int listingsid = resultSet.getInt("listingsid");
        	int id = resultSet.getInt("nftid");
            int duration = resultSet.getInt("durationMonths");
            String dateListed = resultSet.getString("dateListed");
            int cost = resultSet.getInt("cost");
            String activity = resultSet.getString("activity");
            
             
            listings newListings = new listings(listingsid, id,duration, dateListed, cost, activity);
            listListings.add(newListings);
        }        
        resultSet.close();
        disconnect();        
        return listListings;
    }
    
    protected void disconnect() throws SQLException {
        if (connect != null && !connect.isClosed()) {
        	connect.close();
        }
    }
    
    public void insert(listings listings) throws SQLException {
    	connect_func("root","pass1234");         
		String sql = "insert into Listings(nftid, durationMonths, dateListed, cost, activity) values (?, ?, ?, ?, ?)";
		preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
			preparedStatement.setString(1, String.valueOf(listings.getNftid()));
			preparedStatement.setString(2, String.valueOf(listings.getDuration()));
			preparedStatement.setString(3, listings.getDateListed());
			preparedStatement.setString(4, String.valueOf(listings.getCost()));
			preparedStatement.setString(5, listings.getActiveState());

		preparedStatement.executeUpdate();
        preparedStatement.close();
    }
    
    public boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM Listings WHERE nftid = ?";        
        connect_func();
         
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, String.valueOf(id));
         
        boolean rowDeleted = preparedStatement.executeUpdate() > 0;
        preparedStatement.close();
        return rowDeleted;     
    }
     
    public boolean update(listings listings) throws SQLException {
        String sql = "update Listings set nftid=?, durationMonths =?,dateListed = ?,cost=?, activity=? where nftid = ?";
        connect_func();
        
        preparedStatement.setString(1, String.valueOf(listings.getNftid()));
		preparedStatement.setString(2, String.valueOf(listings.getDuration()));
		preparedStatement.setString(3, listings.getDateListed());
		preparedStatement.setString(4, String.valueOf(listings.getCost()));
		preparedStatement.setString(5, listings.getActiveState());
		
         
        boolean rowUpdated = preparedStatement.executeUpdate() > 0;
        preparedStatement.close();
        return rowUpdated;     
    }
    
    public listings getListings(int nftid) throws SQLException {
    	listings listings = null;
        String sql = "SELECT * FROM Listings WHERE nftid = ?";
         
        connect_func();
         
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, String.valueOf(nftid));
         
        ResultSet resultSet = preparedStatement.executeQuery();
         
        if (resultSet.next()) {
        	int id = resultSet.getInt("nftid");
            int duration = resultSet.getInt("durationMonths");
            String dateListed = resultSet.getString("dateListed");
            int cost = resultSet.getInt("cost");
            String activity = resultSet.getString("activity");
        }
         
        resultSet.close();
        statement.close();
         
        return listings;
    }
    
    
    
    public void init() throws SQLException, FileNotFoundException, IOException{
    	connect_func();
        statement =  (Statement) connect.createStatement();
        
        String[] INITIAL = {"use projectdb; ",
					        "drop table if exists Nft; ",
					        ("CREATE TABLE if not exists Listings( " +
					            "listingsid int auto_increment NOT NULL UNIQUE, " + 
					            "nftid int NOT NULL UNIQUE, " +
					            "durationMonths int NOT NULL, " +
					            "dateListed DATE NOT NULL, " +
					            "cost DECIMAL(13,2) NOT NULL," +
					            "activity ENUM('active', 'sold', 'expired') NOT NULL," +
					            "PRIMARY KEY (listingsid) "+"); ")
        					};
        String[] TUPLES = {("insert into Listings(nftid, durationMonths, dateListed, cost, activity)"+
        			"values ('3', '2', '2022-09-27', '50', 'sold'),"
        			+ "('2', '1', '2022-09-20', '100', 'active'),"
        			+ "		('1', '3', '2022-08-20', '75', 'active'),"
        			+ "     ('5', '1', '2022-08-28', '150', 'expired'),"
        			+ "     ('6', '1', '2022-10-05', '2000', 'active'),"
        			+ "     ('7', '2', '2022-07-15', '20', 'expired'),"
        			+ "     ('9', '3', '2022-10-05', '5', 'active'),"
        			+ "     ('10', '1', '2022-10-10', '100', 'sold'),"
        			+ "     ('4', '2', '2022-09-18', '80', 'active'),"
        			+ "     ('8', '2', '2022-09-15', '90', 'sold');")
			    			};
        
        //for loop to put these in database
        for (int i = 0; i < INITIAL.length; i++)
        	statement.execute(INITIAL[i]);
        for (int i = 0; i < TUPLES.length; i++)	
        	statement.execute(TUPLES[i]);
        disconnect();
    }
    
    
   
    
    
    
    
    
	
	

}
