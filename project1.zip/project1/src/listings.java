public class listings 
{
		protected int listingsid;
		protected int nftid;
		protected int duration;
	    protected String dateListed;
	    protected int cost;
	    protected String activeState;
	 
	    //constructors
	    public listings() {
	    }

	    public listings(int ID, int nftId, int duration, String date,int cost, String active) 
	    {
	    	this.listingsid = ID;
	    	this.nftid = nftId;
	    	this.duration = duration;
	    	this.dateListed = date;
	    	this.cost = cost;
	    	this.activeState = active;
	    }
	    
	   //getter and setter methods
		public int getNftid() {
			return nftid;
		}
		public void setNftid(int nftid) {
			this.nftid = nftid;
		}
		public int getDuration() {
			return duration;
		}
		public void setDuration(int duration) {
			this.duration = duration;
		}
		public String getDateListed() {
			return dateListed;
		}
		public void setDateListed(String dateListed) {
			this.dateListed = dateListed;
		}
		public int getCost() {
			return cost;
		}
		public void setCost(int cost) {
			this.cost = cost;
		}
		public String getActiveState() {
			return activeState;
		}
		public void setActiveState(String activeState) {
			this.activeState = activeState;
		}
		public int getListingsid() {
			return listingsid;
		}
	}