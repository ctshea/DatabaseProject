<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
 <%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
 <%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
 
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Root page</title>
</head>
<body>

<div align = "center">
	
	<form action = "initialize">
		<input type = "submit" value = "Initialize the Database"/>
	</form>
	<a href="login.jsp"target ="_self" > logout</a><br><br> 

<h1>List all data</h1>
    <div align="center">
        <table border="1" cellpadding="6">
            <caption><h2>List of Users</h2></caption>
            <tr>
                <th>Email</th>
                <th>First name</th>
                <th>Last name</th>
                <th>Address</th>
                <th>Password</th>
                <th>Birthday</th>
                <th>eth_bal($)</th>
            </tr>
			<c:forEach var="users" items="${listUser}"> 
                <tr style="text-align:center">
                     <td><c:out value="${users.email}" /></td>
                    <td><c:out value="${users.firstName}" /></td>
                    <td><c:out value="${users.lastName}" /></td>
                    <td><c:out value= "${users.adress_street_num} ${users.adress_street} ${users.adress_city} ${users.adress_state} ${users.adress_zip_code}" /></td>
                    <td><c:out value="${users.password}" /></td>
                    <td><c:out value="${users.birthday}" /></td>
                    <td><c:out value="${users.eth_bal}"/></td> 
             </c:forEach>
        </table>
	</div>
    <div align="center">
        <table border="1" cellpadding="6">
            <caption><h2>List of Nfts</h2></caption>
            <tr>
            	<th>ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Image</th>
                <th>Owner Email</th>
                <th>Listed</th>
                <th>Original Owner</th>
                <th>Date Minted</th>
            </tr>
            <c:forEach var="nfts" items="${listNft}">
                <tr style="text-align:center">
                	<td><c:out value="${nfts.nftid}" /></td>
                    <td><c:out value="${nfts.name}" /></td>
                    <td><c:out value="${nfts.description}" /></td>
                    <td><c:out value="${nfts.image}" /></td>
                    <td><c:out value="${nfts.userEmail}" /></td>
                    <td><c:out value="${nfts.listed}" /></td>
                    <td><c:out value="${nfts.originalOwner}" /></td>
                    <td><c:out value="${nfts.dateMinted}" /></td>
            </c:forEach>
        </table>
 	<div align="center">
        <table border="1" cellpadding="6">
            <caption><h2>List of Listings</h2></caption>
            <tr>
            	<th>Listings ID</th>
            	<th>NFT ID</th>
                <th>Duration(Days)</th>
                <th>Date Listed</th>
                <th>Cost</th>
                <th>Activity</th>
            </tr>
            <c:forEach var="listings" items="${listListings}">
                <tr style="text-align:center">
                    <td><c:out value="${listings.listingsid}" /></td>
                 	<td><c:out value="${listings.nftid}" /></td>
                    <td><c:out value="${listings.duration}" /></td>
                    <td><c:out value="${listings.dateListed}" /></td>
                    <td><fmt:formatNumber type="number" minFractionDigits="2" maxFractionDigits="2" value="${listings.cost}"/></td>
                    <td><c:out value="${listings.activeState}" /></td>
            </c:forEach>
        </table>
	</div> 
	<div align="center">
        <table border="1" cellpadding="6">
            <caption><h2>List of Transactions</h2></caption>
            <tr>
            	<th>Transactions ID</th>
            	<th>Receiver</th>
                <th>Sender</th>
                <th>Date Completed</th>
                <th>Transaction Type</th>
                <th>NFT ID</th>
                <th>Listings ID</th>
            </tr>
            <c:forEach var="transactions" items="${listTransactions}">
                <tr style="text-align:center">
                    <td><c:out value="${transactions.transactionid}" /></td>
                 	<td><c:out value="${transactions.userIdBuyer}" /></td>
                    <td><c:out value="${transactions.userIdSeller}" /></td>
                    <td><c:out value="${transactions.dateCompleted}" /></td>
                    <td><c:out value="${transactions.type}" /></td>
                    <td><c:out value="${transactions.nftid}" /></td>
                    <td><c:out value="${transactions.listingsid}" /></td>
            </c:forEach>
        </table>
	</div> 
	

</body>
</html>