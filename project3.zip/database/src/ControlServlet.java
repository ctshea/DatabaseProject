import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.text.DateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.sql.PreparedStatement;

public class ControlServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private userDAO userDAO = new userDAO();
	private nftDAO nftDAO = new nftDAO();
	private listingsDAO listingsDAO = new listingsDAO();
	private transactionsDAO transactionsDAO = new transactionsDAO();
	private String currentUser;
	private HttpSession session = null;

	public ControlServlet() {

	}

	public void init() {
		nftDAO = new nftDAO();
		userDAO = new userDAO();
		listingsDAO = new listingsDAO();
		transactionsDAO = new transactionsDAO();
		currentUser = "";
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();
		System.out.println(action);

		try {
			switch (action) {	
			 case "/viewNft":
				 viewNft(request, response);
				 break;
			 case "/viewProfile":
				 viewProfile(request, response);
				 break;
			 case "/userSearch":
				 searchUsers(request, response);
				 break;
			 case "/purchaseNft":
				 purchaseNft(request, response);
				 break;			 
			case "/nftSearch":
				searchNfts(request, response);
				break;
			case "/changeEth":
				changeEth(request, response);
				break;
			case "/delisting":
				delisting(request, response);
				break;
			case "/listing":
				listing(request, response);
				break;
			case "/transfer":
				transfer(request, response);
				break;
			case "/mint":
				mint(request, response);
				break;
			case "/login":
				login(request, response);
				break;
			case "/register":
				register(request, response);
				break;
			case "/initialize":
				userDAO.init();
				nftDAO.init();
				transactionsDAO.init();
				listingsDAO.init();
				nftDAO.update();
				System.out.println("Database successfully initialized!");
				break;
			case "/root":
				rootPage(request, response, "");
				break;
			case "/logout":
				logout(request, response);
				break;
			case "/list":
				System.out.println("The action is: list");
				listUser(request, response);
				listNft(request, response);
				listListings(request, response);
				listTransactions(request, response);
				break;
			}
		} catch (Exception ex) {
			System.out.println(ex.getMessage());
		}
	}

	private void listUser(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		System.out.println("listUser started: 00000000000000000000000000000000000");

		List<user> listUser = userDAO.listAllUsers();
		request.setAttribute("listUser", listUser);
		RequestDispatcher dispatcher = request.getRequestDispatcher("UserList.jsp");
		dispatcher.forward(request, response);

		System.out.println("listPeople finished: 111111111111111111111111111111111111");
	}

	private void listNft(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		System.out.println("listNft started: 000000000000000111111111111111111");

		List<nft> listNft = nftDAO.listAllNfts();
		request.setAttribute("listNft", listNft);
		// RequestDispatcher dispatcher = request.getRequestDispatcher("UserList.jsp");
		// dispatcher.forward(request, response);

		System.out.println("listNFTs finished: 111111111111111111111111111111111111");
	}

	private void listListings(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		System.out.println("listListins started: 11111000000000000111111111111111111");

		List<listings> listListings = listingsDAO.listAllListings();
		request.setAttribute("listListings", listListings);
		// RequestDispatcher dispatcher = request.getRequestDispatcher("UserList.jsp");
		// dispatcher.forward(request, response);

		System.out.println("listListings finished: 111111111111111111111111111111111111");
	}

	private void listTransactions(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		System.out.println("listListins started: 11111000000111120000111111111111111111");

		List<transactions> listTransactions = transactionsDAO.listAllTransactions();
		request.setAttribute("listTransactions", listTransactions);
		// RequestDispatcher dispatcher = request.getRequestDispatcher("UserList.jsp");
		// dispatcher.forward(request, response);

		System.out.println("listTransactions finished: 111111111111111111111111111111111111");
	}

	private void rootPage(HttpServletRequest request, HttpServletResponse response, String view)
			throws ServletException, IOException, SQLException {
		System.out.println("root view");
		request.setAttribute("listUser", userDAO.listAllUsers());
		request.setAttribute("listNft", nftDAO.listAllNfts());
		request.setAttribute("listListings", listingsDAO.listAllListings());
		request.setAttribute("listTransactions", transactionsDAO.listAllTransactions());
		request.getRequestDispatcher("rootView.jsp").forward(request, response);
	}

	protected void login(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		String email = request.getParameter("email");
		String password = request.getParameter("password");

		
		if (email.equals("root") && password.equals("pass1234")) {
			System.out.println("Login Successful! Redirecting to root");
			session = request.getSession();
			session.setAttribute("username", email);
			rootPage(request, response, "");
		} else if (userDAO.isValid(email, password)) {
			currentUser = email;
			listingsDAO.updateListingStatus();
			System.out.println("Login Successful! Redirecting");
			request.setAttribute("user", userDAO.getUser(currentUser));
			request.setAttribute("userNfts", nftDAO.getNft(currentUser));
			request.setAttribute("listedUserNfts", listingsDAO.listAllUserListings(currentUser));
			request.setAttribute("listedActiveNfts", listingsDAO.listAllActiveListings(currentUser));
			request.setAttribute("listedUsers", userDAO.listAllUsers());
			request.setAttribute("nftList", nftDAO.listAllNfts());
			request.setAttribute("mintedByUser", nftDAO.getNftsMinted(currentUser));
			request.setAttribute("soldByUser", transactionsDAO.listUserSales(true, currentUser));
			request.setAttribute("purchasedByUser", transactionsDAO.listUserSales(false, currentUser));		 
			request.getRequestDispatcher("activitypage.jsp").forward(request, response);

		} else {
			request.setAttribute("loginStr", "Login Failed: Please check your credentials.");
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}
		
		System.out.println("current user is: " + currentUser);
	}

	private void register(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		String email = request.getParameter("email");
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String password = request.getParameter("password");
		String birthday = request.getParameter("birthday");
		String adress_street_num = request.getParameter("adress_street_num");
		String adress_street = request.getParameter("adress_street");
		String adress_city = request.getParameter("adress_city");
		String adress_state = request.getParameter("adress_state");
		String adress_zip_code = request.getParameter("adress_zip_code");
		String confirm = request.getParameter("confirmation");
		BigDecimal startAmount = new BigDecimal(100);
		if (password.equals(confirm)) {
			if (!userDAO.checkEmail(email)) {
				System.out.println("Registration Successful! Added to database");
				user users = new user(email, firstName, lastName, password, birthday, adress_street_num, adress_street,
						adress_city, adress_state, adress_zip_code, startAmount);
				userDAO.insert(users);
				response.sendRedirect("login.jsp");
			} else {
				System.out.println("Username taken, please enter new username");
				request.setAttribute("errorOne", "Registration failed: Username taken, please enter a new username.");
				request.getRequestDispatcher("register.jsp").forward(request, response);
			}
		} else {
			System.out.println("Password and Password Confirmation do not match");
			request.setAttribute("errorTwo", "Registration failed: Password and Password Confirmation do not match.");
			request.getRequestDispatcher("register.jsp").forward(request, response);
		}
	}

	private void mint(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		String name = request.getParameter("name");
		String description = request.getParameter("description");
		String imagePath = request.getParameter("imagePath");

		if (nftDAO.checkNftImagePath(imagePath)) {
			request.setAttribute("errorOne", "NFT minting failed: image taken, please enter a new image url.");
			request.getRequestDispatcher("nftMinting.jsp").forward(request, response);
		} else if (nftDAO.checkNftName(name)) {
			request.setAttribute("errorOne", "NFT minting failed: NFT name taken, please enter a new NFT name.");
			request.getRequestDispatcher("nftMinting.jsp").forward(request, response);
		} else {
			LocalDateTime currentDate = LocalDateTime.now();
			nft nfts = new nft(name, description, imagePath, currentUser, "n", currentUser, currentDate.toString());
			nftDAO.insert(nfts);
			request.setAttribute("userNfts", nftDAO.getNft(currentUser));
			request.setAttribute("nftList", nftDAO.listAllNfts());
			request.setAttribute("mintedByUser", nftDAO.getNftsMinted(currentUser));
			request.getRequestDispatcher("activitypage.jsp").forward(request, response);
		}
	}

	private void transfer(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		String transferToName = request.getParameter("name");
		String nftname = request.getParameter("nftname");

		if (!userDAO.checkEmail(transferToName)) { // user does not exist
			request.setAttribute("errorOne", "This user does not exist, please enter an active user.");
			request.getRequestDispatcher("Transfer.jsp").forward(request, response);
		} else {
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDateTime currentDate = LocalDateTime.now();
			nft nfts = nftDAO.getSingleNft(nftname);
			int nftId = nfts.getNftid();
			nft toInsertNft = new nft(nftId, nfts.getName(), nfts.getDescription(), nfts.getImage(), transferToName, "n", nfts.getOriginalOwner(), nfts.getDateMinted());
			nftDAO.update(toInsertNft);
			transactions transaction = new transactions(transferToName, currentUser, currentDate.toString(), "transfer", nftId, null);
			transactionsDAO.insert(transaction); request.setAttribute("userNfts", nftDAO.getNft(currentUser));
			request.getRequestDispatcher("activitypage.jsp").forward(request, response);
		}
	}
	
	private void listing(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		String duration = request.getParameter("Duration");
		String amount = request.getParameter("Amount");
		String nftname = request.getParameter("nftname");

		if (!duration.equals(null) && !amount.equals(null)) {
			int durationInt = Integer.parseInt(duration);
			double amountDbl = Double.parseDouble(amount);
			if (durationInt <= 0 || durationInt >100) {
				request.setAttribute("errorOne", "The duration must be between 1 and 100 days, enter a valid duration.");
				request.getRequestDispatcher("List.jsp").forward(request, response);
			} else if (amountDbl <= 0 || amountDbl > 10000) {
				request.setAttribute("errorTwo", "The amount must be between 1 and 10000 eth, enter a valid amount.");
				request.getRequestDispatcher("List.jsp").forward(request, response);
			} else {
				nft nfts = nftDAO.getSingleNft(nftname);
				int nftId = nfts.getNftid();
				nftDAO.update(nftId, "y");
				DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				LocalDateTime currentDate = LocalDateTime.now();
				BigDecimal costFormatted = new BigDecimal(amountDbl);
				listings listing = new listings(nftId, durationInt, currentDate.toString(), costFormatted, "active");
				listingsDAO.insert(listing);
				request.setAttribute("userNfts", nftDAO.getNft(currentUser));
				request.setAttribute("listedUserNfts", listingsDAO.listAllUserListings(currentUser));
				request.getRequestDispatcher("activitypage.jsp").forward(request, response);
			}
		} else {
			request.setAttribute("errorThree", "No fields can be left blank, enter valid data.");
			request.getRequestDispatcher("List.jsp").forward(request, response);
		}
		
	}

	private void delisting(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		int nftid = Integer.parseInt(request.getParameter("nftid"));
		listingsDAO.update(nftid, "cancelled");
		nftDAO.update(nftid, "n");
		request.setAttribute("listedUserNfts", listingsDAO.listAllUserListings(currentUser));
		request.setAttribute("userNfts", nftDAO.getNft(currentUser));
		request.getRequestDispatcher("activitypage.jsp").forward(request, response);
	}
	
	private void changeEth(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		String ethAmount = request.getParameter("ethAmount");
		String currentBalance = request.getParameter("currentBalance");
		double amountDbl = Double.parseDouble(ethAmount);
		double balanceDbl = Double.parseDouble(currentBalance);
		if (request.getParameter("addEth") != null) {
			if (amountDbl <= 0 || amountDbl > 10000) {
				request.setAttribute("errorOne", "You must enter between 1 and 10,000 eth.");
				request.getRequestDispatcher("ChangeBalance.jsp").forward(request, response);
			}
			else if (balanceDbl + amountDbl > 15000) {
				request.setAttribute("errorTwo", "This would put you over the maximum amount of eth (15,000).");
				request.getRequestDispatcher("ChangeBalance.jsp").forward(request, response);
			} else {
				BigDecimal costFormattedAmount = new BigDecimal(amountDbl);
				BigDecimal costFormattedBalance = new BigDecimal(balanceDbl);
				BigDecimal toReturn = costFormattedAmount.add(costFormattedBalance);
				userDAO.updateEth(toReturn, currentUser);
				request.setAttribute("user", userDAO.getUser(currentUser));
				request.getRequestDispatcher("activitypage.jsp").forward(request, response);
			}
		}
		else if (request.getParameter("removeEth") != null) {
			if (amountDbl <= 0 || amountDbl > balanceDbl) {
				request.setAttribute("errorThree", "You must enter more than 0 and less than your current balance.");
				request.getRequestDispatcher("ChangeBalance.jsp").forward(request, response);
			} else {
				BigDecimal costFormattedAmount = new BigDecimal(amountDbl);
				BigDecimal costFormattedBalance = new BigDecimal(balanceDbl);
				BigDecimal toReturn = costFormattedBalance.subtract(costFormattedAmount);				
				userDAO.updateEth(toReturn, currentUser);
				request.setAttribute("user", userDAO.getUser(currentUser));
				request.getRequestDispatcher("activitypage.jsp").forward(request, response);
			}
		}

	}

	private void search(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		String searchName = request.getParameter("name");
		listingsDAO.updateListingStatus();
		if (request.getParameter("search") != null) {
			request.setAttribute("listedActiveNfts", listingsDAO.listAllSearchedListings(currentUser, searchName));
		} else if  (request.getParameter("reset") != null) {
			request.setAttribute("listedActiveNfts", listingsDAO.listAllActiveListings(currentUser));
		}
		request.getRequestDispatcher("ListingsPage.jsp").forward(request, response);
	}
	
	
	private void purchaseNft(HttpServletRequest request, HttpServletResponse
	response) throws ServletException, IOException, SQLException {
	String userBalance = request.getParameter("currentBalance");
	String cost = request.getParameter("cost");
	String sell = request.getParameter("seller");
	int nftid = Integer.parseInt(request.getParameter("nftid"));
	String listingsid = request.getParameter("listingsid");
	double costDbl = Double.parseDouble(cost);
	double balanceDbl = Double.parseDouble(userBalance);
	user seller = userDAO.getUser(sell);
	BigDecimal sellerPriorBalance = seller.getEth_bal();
	if (costDbl > balanceDbl) {
		request.setAttribute("errorOne", "You cannot afford that, add more eth or buy a different nft.");
		request.getRequestDispatcher("ListingsPage.jsp").forward(request, response);
	} else {
		BigDecimal costFormattedAmount = new BigDecimal(costDbl);
		BigDecimal costFormattedBalance = new BigDecimal(balanceDbl);
		BigDecimal buyerBalance = costFormattedBalance.subtract(costFormattedAmount);
		BigDecimal sellerBalance = sellerPriorBalance.add(costFormattedAmount);
		userDAO.updateEth(sellerBalance, sell);
		userDAO.updateEth(buyerBalance, currentUser);
		LocalDateTime currentDate = LocalDateTime.now();
		transactions transaction = new transactions(currentUser, sell, currentDate.toString(), "sale", nftid , listingsid);
		transactionsDAO.insert(transaction);
		nftDAO.update(currentUser, nftid);
		listingsDAO.update(nftid, "sold");
		request.setAttribute("user", userDAO.getUser(currentUser));
		request.setAttribute("userNfts", nftDAO.getNft(currentUser));
		request.setAttribute("listedUserNfts", listingsDAO.listAllUserListings(currentUser));
		request.setAttribute("listedActiveNfts", listingsDAO.listAllActiveListings(currentUser));
		request.getRequestDispatcher("activitypage.jsp").forward(request, response);
		}
	}
	
	private void searchUsers(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		String searchName = request.getParameter("name");
		if (request.getParameter("search") != null) {
			request.setAttribute("listedUsers", userDAO.searchAllUsers(searchName));
		} else if  (request.getParameter("reset") != null) {
			request.setAttribute("listedUsers", userDAO.listAllUsers());
			//request.setAttribute("listedUsers", userDAO.listAllUsers());	
		}
		request.getRequestDispatcher("userSearch.jsp").forward(request, response);
	}
	
	private void searchNfts(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		String searchName = request.getParameter("name");
		if (request.getParameter("search") != null) {
			request.setAttribute("nftList", nftDAO.searchAllNfts(searchName));
		} else if  (request.getParameter("reset") != null) {
			request.setAttribute("nftList", nftDAO.listAllNfts());	
		}
		request.getRequestDispatcher("nftSearch.jsp").forward(request, response);
	}
	
	private void viewProfile(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		String userName = request.getParameter("userProfile");
		request.setAttribute("profileUser", userDAO.getUser(userName));
		request.setAttribute("userNfts", nftDAO.getUserNfts(userName));
		request.getRequestDispatcher("UserProfile.jsp").forward(request, response);
	}
	
	private void viewNft(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException {
		String nftName = request.getParameter("nftName");
		nft nft = nftDAO.getSingleNft(nftName);
		request.setAttribute("nft", nft);
		request.setAttribute("nftTransferred", transactionsDAO.ListNftTransactions(nft.getNftid(), "transfer"));
		request.setAttribute("nftSold", transactionsDAO.ListNftTransactions(nft.getNftid(), "sale"));
		request.getRequestDispatcher("NftProfile.jsp").forward(request, response);
	}
	
	private void logout(HttpServletRequest request, HttpServletResponse response) throws IOException {
		currentUser = "";
		response.sendRedirect("login.jsp");
	}
	


}
