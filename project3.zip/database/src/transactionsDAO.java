import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.PreparedStatement;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
import java.sql.ResultSet;
//import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
/**
 * Servlet implementation class Connect
 */
@WebServlet("/transactionsDAO")
public class transactionsDAO 
{
	private static final long serialVersionUID = 1L;
	private Connection connect = null;
	private Statement statement = null;
	private PreparedStatement preparedStatement = null;
	private ResultSet resultSet = null;
	
	public transactionsDAO(){}
	
	/** 
	 * @see HttpServlet#HttpServlet()
     */
    protected void connect_func() throws SQLException {
    	//uses default connection to the database
        if (connect == null || connect.isClosed()) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                throw new SQLException(e);
            }
            connect = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/projectdb?allowPublicKeyRetrieval=true&useSSL=false&user=john&password=pass1234");
            System.out.println(connect);
        }
    }
    
    public boolean database_login(String email, String password) throws SQLException{
    	try {
    		connect_func("root","pass1234");
    		String sql = "select * from user where email = ?";
    		preparedStatement = connect.prepareStatement(sql);
    		preparedStatement.setString(1, email);
    		ResultSet rs = preparedStatement.executeQuery();
    		return rs.next();
    	}
    	catch(SQLException e) {
    		System.out.println("failed login");
    		return false;
    	}
    }
	//connect to the database 
    public void connect_func(String username, String password) throws SQLException {
        if (connect == null || connect.isClosed()) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                throw new SQLException(e);
            }
            connect = (Connection) DriverManager
  			      .getConnection("jdbc:mysql://127.0.0.1:3306/userdb?"
  			          + "useSSL=false&user=" + username + "&password=" + password);
            System.out.println(connect);
        }
    }
    
    public List<transactions> ListNftTransactions(int nftid, String activity) throws SQLException {
    	transactions transactions;
        List<transactions> listTransactions = new ArrayList<transactions>();        
        String sql = "SELECT * FROM Transactions where nftid = ? and transactionType = ?";      
        connect_func();
        
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, String.valueOf(nftid));
        preparedStatement.setString(2, activity);
        
        ResultSet resultSet = preparedStatement.executeQuery();
         
        while (resultSet.next()) {
        	int transactionid = resultSet.getInt("transactionid");
        	String buyer = resultSet.getString("userEmailBuyer");
            String seller = resultSet.getString("userEmailSeller");
            String dateCompleted = resultSet.getString("dateCompleted");
            String type = resultSet.getString("transactionType");
            int nftId = resultSet.getInt("nftid");
            int listingsId = resultSet.getInt("listingsId");
            
            transactions = new transactions(transactionid, buyer, seller, dateCompleted, type, nftId, String.valueOf(listingsId));
            listTransactions.add(transactions);
        }        
        resultSet.close();
        disconnect();        
        return listTransactions;
    }
    
    
    public List<transactions> listUserSales(boolean saleOrBuy, String userName) throws SQLException {	//false for buy, true for sale
    	transactions transactions;
        List<transactions> listTransactions = new ArrayList<transactions>();     
        String sql;
        if (saleOrBuy) {
        	sql = "SELECT * FROM transactions INNER JOIN nft ON nft.nftid = transactions.nftid INNER JOIN listings "
        		  + "ON listings.listingsid = transactions.listingsid WHERE userEmailSeller = ?";    
        } else {
            sql = "SELECT * FROM transactions INNER JOIN nft ON nft.nftid = transactions.nftid INNER JOIN listings "
          		  + "ON listings.listingsid = transactions.listingsid WHERE userEmailBuyer = ?";
        }
        connect_func();
        
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, userName);
         
        ResultSet resultSet = preparedStatement.executeQuery();
        
        while (resultSet.next()) {
            String buyer = resultSet.getString("userEmailBuyer");
            String seller = resultSet.getString("userEmailSeller");
            String dateCompleted = resultSet.getString("dateCompleted");
            String nftName = resultSet.getString("nftname");
            double cost = resultSet.getDouble("cost");
            BigDecimal costFormatted = new BigDecimal(cost);
            if (saleOrBuy) {
                transactions = new transactions(buyer, dateCompleted, nftName, costFormatted);
            } else {
                transactions = new transactions(seller, dateCompleted, nftName, costFormatted);	
            }
            listTransactions.add(transactions);
        }        
        resultSet.close();
        disconnect();        
        return listTransactions;
    }
    
    public List<transactions> listAllTransactions() throws SQLException {
    	transactions transactions;
        List<transactions> listTransactions = new ArrayList<transactions>();        
        String sql = "SELECT * FROM Transactions";      
        connect_func();      
        statement = (Statement) connect.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);
         
        while (resultSet.next()) {
        	int transactionid = resultSet.getInt("transactionid");
        	String buyer = resultSet.getString("userEmailBuyer");
            String seller = resultSet.getString("userEmailSeller");
            String dateCompleted = resultSet.getString("dateCompleted");
            String type = resultSet.getString("transactionType");
            int nftId = resultSet.getInt("nftid");
            int listingsId = resultSet.getInt("listingsId");
            
             if (listingsId == 0) {	//it was direct transfer -> listingID will be null.
            transactions = new transactions(transactionid, buyer,seller, dateCompleted, type, nftId, "-");
             } else {
            transactions = new transactions(transactionid, buyer,seller, dateCompleted, type, nftId, String.valueOf(listingsId));
             }
            listTransactions.add(transactions);
        }        
        resultSet.close();
        disconnect();        
        return listTransactions;
    }
    
    
    
    protected void disconnect() throws SQLException {
        if (connect != null && !connect.isClosed()) {
        	connect.close();
        }
    }
    
    public void insert(transactions transactions) throws SQLException {
    	//connect_func("root","pass1234");
    	connect_func();
		String sql = "insert into Transactions(userEmailBuyer, userEmailSeller, dateCompleted, transactionType, nftid, listingsid) values (?, ?, ?, ?, ?, ?)";
		preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
			preparedStatement.setString(1, transactions.getUserIdBuyer());
			preparedStatement.setString(2, transactions.getUserIdSeller());
			preparedStatement.setString(3, transactions.getDateCompleted());
			preparedStatement.setString(4, transactions.getType());
			preparedStatement.setString(5, String.valueOf(transactions.getNftid()));
			preparedStatement.setString(6, transactions.getListingsid());	// "-" for null
			
		preparedStatement.executeUpdate();
        preparedStatement.close();
    }
    
    
    public boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM Transactions WHERE transactionid = ?";        
        connect_func();
         
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, String.valueOf(id));
         
        boolean rowDeleted = preparedStatement.executeUpdate() > 0;
        preparedStatement.close();
        return rowDeleted;     
    }
     
    public boolean update(transactions transactions) throws SQLException {
        String sql = "update Transactions set userIdBuyer=?, userIdSeller =?,dateCompleted = ?,type=?, nftid=?, listingsid=? where transactionid = ?";
        connect_func();
        
        preparedStatement.setString(1, transactions.getUserIdBuyer());
		preparedStatement.setString(2, transactions.getUserIdSeller());
		preparedStatement.setString(3, transactions.getDateCompleted());
		preparedStatement.setString(4, transactions.getType());
		preparedStatement.setString(5, String.valueOf(transactions.getNftid()));
		preparedStatement.setString(6, transactions.getListingsid());	// "-" for null
		
         
        boolean rowUpdated = preparedStatement.executeUpdate() > 0;
        preparedStatement.close();
        return rowUpdated;     
    }
    
    public transactions getTransactionss(int trnsactionid) throws SQLException {
    	transactions transactions = null;
        String sql = "SELECT * FROM Transactions WHERE transactionid = ?";
         
        connect_func();
         
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, String.valueOf(trnsactionid));
         
        ResultSet resultSet = preparedStatement.executeQuery();
         
        if (resultSet.next()) {
        	int transactionid = resultSet.getInt("transactionid");
        	String buyer = resultSet.getString("userEmailBuyer");
            String seller = resultSet.getString("userEmailSeller");
            String dateCompleted = resultSet.getString("dateCompleted");
            String type = resultSet.getString("transactionType");
            int nftId = resultSet.getInt("nftid");
            String listingsId = resultSet.getString("listingsId");
            transactions = new transactions(buyer, seller, dateCompleted, type, nftId, listingsId);
        }
         
        resultSet.close();
        statement.close();
         
        return transactions;
    }
    
    
    
    public void init() throws SQLException, FileNotFoundException, IOException{
    	connect_func();
        statement =  (Statement) connect.createStatement();
        
        String[] INITIAL = {"use projectdb; ",
					        "drop table if exists Transactions; ",
					        ("CREATE TABLE if not exists Transactions( " +
					            "transactionid int auto_increment NOT NULL UNIQUE, " + 
					            "userEmailBuyer VARCHAR(50) NOT NULL, "+
					            "userEmailSeller VARCHAR(50) NOT NULL, "+
					            "dateCompleted DATE NOT NULL, "+
					            "transactionType ENUM('transfer', 'sale') NOT NULL," +
					            "nftid int NOT NULL," +
					            "listingsid int," +
					            "PRIMARY KEY (transactionid) "+"); ")
        					};
        String[] TUPLES = {("insert into Transactions(userEmailBuyer, userEmailSeller, dateCompleted, transactionType, nftid, listingsid)"+
        			"values ('susie@gmail.com' , 'angelo@gmail.com', '2022-09-19', 'transfer' ,'6', null),"
        			+ "		('susie@gmail.com' , 'jeannette@gmail.com', '2022-09-19', 'sale','3', '1'),"
        			+ "     ('cody@gmail.com' , 'susie@gmail.com', '2022-10-12', 'sale', '10', '8'),"
        			+ "     ('ashley@gmail.com' , 'rudy@gmail.com', '2022-09-19', 'transfer', '5', null),"
        			+ "     ('rudy@gmail.com' , 'ashley@gmail.com', '2022-09-19', 'transfer', '2', null),"
        			+ "     ('angelo@gmail.com' , 'rudy@gmail.com', '2022-09-21', 'transfer', '2', null),"
        			+ "     ('todd@gmail.com' , 'cody@gmail.com', '2022-09-19', 'transfer', '10', null),"
        			+ "     ('susie@gmail.com' , 'sophie@gmail.com', '2022-09-22', 'transfer' ,'7', null),"
        			+ "     ('angelo@gmail.com' , 'todd@gmail.com', '2022-09-25', 'sale','8', '10'),"
        			+ "     ('jeannette@gmail.com' , 'cody@gmail.com', '2022-10-14', 'transfer', '8', null);")
			    			};
        
        //for loop to put these in database
        for (int i = 0; i < INITIAL.length; i++)
        	statement.execute(INITIAL[i]);
        for (int i = 0; i < TUPLES.length; i++)	
        	statement.execute(TUPLES[i]);
        disconnect();
    }
    
    
   
    
    
    
    
    
	
	

}
