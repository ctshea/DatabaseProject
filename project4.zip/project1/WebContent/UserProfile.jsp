<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %> 
    
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Profile Page</title>
</head>
<center><h1>Showing user profile for: <c:out value="${profileUser.email}" /></h1> </center>
<div align="center">
	<body>
	 <center>
		 <a href="userSearch.jsp"target ="_self" > Back to User Search</a><br><br> 
    	<div align="center">
    	        <table border="1" cellpadding="6">
            <tr>
                <th><c:out value="${profileUser.email}" /> balance(eth): 
                <c:out value="${profileUser.eth_bal}"/></th>
            </tr>
        </table>
			<table border="1" cellpadding="6">
            <caption><h2>All NFTs that <c:out value="${profileUser.email}" /> owns</h2></caption>
            <tr>
            	<th>Nft Name</th>
                <th>Nft Description</th>
                <th>Nft Image Url</th>
            </tr>
      			<c:forEach var="userNfts" items="${userNfts}"> 
                <tr style="text-align:center">
                    <td><c:out value="${userNfts.name}" /></td>
                    <td><c:out value="${userNfts.description}" /></td>
                    <td><c:out value="${userNfts.image}" /></td>
					</tr>
             </c:forEach>
        </table>

	</div>
		 </center>
		 </div>
	</body>
</html>