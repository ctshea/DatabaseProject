<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %> 
    
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Activity page</title>
</head>

<center><h1>Welcome! This is your homepage.</h1> </center>
<c:set var="user" value="${user}" scope="session" />
<c:set var="userNfts" value="${userNfts}" scope="session" />
<c:set var="listedUserNfts" value="${listedUserNfts}" scope="session" />
<c:set var="listedActiveNfts" value="${listedActiveNfts}" scope="session" />
<c:set var="listedUsers" value="${listedUsers}" scope="session" />
<c:set var="nftList" value="${nftList}" scope="session" />
<c:set var="mintedByUser" value="${mintedByUser}" scope="session" />
<c:set var="soldByUser" value="${soldByUser}" scope="session" />
<c:set var="purchasedByUser" value="${purchasedByUser}" scope="session" />

	<body>
	 <center>
		 <a href="login.jsp?"target ="_self" > logout</a><br><br> 
		 <a href="nftMinting.jsp"target ="_self" > Mint an nft</a><br><br> 
		 <a href="ListingsPage.jsp"target ="_self" > View all active listings</a><br><br> 
		 <a href="userSearch.jsp"target ="_self" > Search users</a><br><br>
		 <a href="nftSearch.jsp"target ="_self" > Search nfts</a><br><br>
		 <a href="nftHistory.jsp"target ="_self" > View your nft history</a><br><br>
    	<div align="center">
     	<caption><h2>Your current eth balance</h2></caption>
        <table border="1" cellpadding="6">
            <tr>
                <th>balance(eth): 
                <c:out value="${user.eth_bal}"/></th>
            </tr>
                <tr style="text-align:center">
					<td><a href="ChangeBalance.jsp"target ="_self" >
                    <input type="submit" value="Add/Remove Eth"/>
                    </a></td>
                </tr>
        </table>
        
         <table border="1" cellpadding="6">
            <caption><h2>Your Unlisted NFTs</h2></caption>
            <tr>
            	<th>Nft ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Image Url</th>
            </tr>
      			<c:forEach var="userNfts" items="${userNfts}"> 
                <tr style="text-align:center">
                    <td><c:out value="${userNfts.nftid}" /></td>
                    <td><c:out value="${userNfts.name}" /></td>
                    <td><c:out value="${userNfts.description}" /></td>
                    <td><a href = "${userNfts.image}"><c:out value="${userNfts.image}" /></a></td>
              		<td align="center" colspan="5">
                    <a href="List.jsp?nftname=${userNfts.name}"target ="_self" >
						<input type="submit" value="List"/>
						</a>
					</td>
                    <td align="center" colspan="5">
                    <a href="Transfer.jsp?nftname=${userNfts.name}"target ="_self" >
						<input type="submit" value="Transfer"/>
						</a>
					</td>
             </c:forEach>
        </table>
                 <table border="1" cellpadding="6">
                    <caption><h2>Your Listed NFTs</h2></caption>
            <tr>
            	<th>Nft ID</th>
                <th>Name</th>
                <th>Duration</th>
                <th>Days Remaining</th>
                <th>Amount</th>
            </tr>
      			<c:forEach var="listedUserNfts" items="${listedUserNfts}"> 
                <tr style="text-align:center">
                    <td><c:out value="${listedUserNfts.nftid}" /></td>
                    <td><c:out value="${listedUserNfts.nftName}" /></td>
                    <td><c:out value="${listedUserNfts.duration}" /></td>
                    <td><c:out value="${listedUserNfts.daysRemaining}" /></td>
                    <td><c:out value="${listedUserNfts.cost}" /></td>
              		<td align="center" colspan="5">
                    <form action="delisting">
                        <input type="hidden" name="nftid" value="${listedUserNfts.nftid}">
						<input type="submit" value="De-list"/>
					</form>
					</td>
             </c:forEach>
        </table>
        
	</div>
		 </center>
	</body>
</html>