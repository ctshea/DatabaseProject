<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %> 
    
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Users</title>
</head>
<center><h1>Search for users</h1> </center>
<div align="center">
	<body>
	 <center>
		 <a href="activitypage.jsp?"target ="_self" > Back to Homepage</a><br><br> 
    	<div align="center">
     	<form action="userSearch">
    	<table border="1" cellpadding="6">
    	    <caption><h2>Showing all active users, enter text below to search by email.</h2></caption>
            <tr>
					<th>Name: </th>
					<td align="center" colspan="3">
						<input type="text" name="name" size="50" value="Name" onfocus="this.value=''">
					</td>
				</tr>

					<tr>
					<td align="center" colspan="5">
						<input type="submit" name= "search" value="Search"/>
						<input type="submit" name = "reset" value="Reset Search"/>
					</td>
				</tr>
				</form>
				</table>
				
			<table border="1" cellpadding="6">
            <caption><h2>List of users</h2></caption>
            <tr>
            	<th>User Email</th>
                <th>First Name</th>
                <th>Last Name</th>
            </tr>
      			<c:forEach var="users" items="${listedUsers}"> 
                <tr style="text-align:center">
                    <td><c:out value="${users.email}" /></td>
                    <td><c:out value="${users.firstName}" /></td>
                    <td><c:out value="${users.lastName}" /></td>              
                    <td><form action="viewProfile">
                   
                    <input type="hidden" name="userProfile" value="${users.email}">
					<input type="submit" value="View Profile"/>
					</form></td>
             </c:forEach>
        </table>
	</div>
		 </center>
		 </div>
	</body>
</html>