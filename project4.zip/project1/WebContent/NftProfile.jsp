<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %> 
    
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Nft Page</title>
</head>
<center><h1>Showing nft profile for: <c:out value="${nft.name}" /></h1> </center>
<div align="center">
	<body>
	 <center>
		 <a href="nftSearch.jsp"target ="_self" > Back to Nft search</a><br><br> 
    	<div align="center">
			<table border="1" cellpadding="6">
            <caption><h2>NFT information</h2></caption>
            <tr>
            	<th>Nft ID</th>
            	<th>Nft Name</th>
                <th>Nft Description</th>
                <th>Nft Image Url</th>
           		<th>Minted by</th>
                <th>Minted on</th>
            </tr>
                <tr style="text-align:center">
                    <td><c:out value="${nft.nftid}" /></td>
                    <td><c:out value="${nft.name}" /></td>
                    <td><c:out value="${nft.description}" /></td>
                    <td><c:out value="${nft.image}" /></td>
                    <td><c:out value="${nft.originalOwner}" /></td>
                    <td><c:out value="${nft.dateMinted}" /></td>
				</tr>
        </table>

			<table border="1" cellpadding="6">
            <caption><h2>NFT transfer history</h2></caption>
            <tr>
            	<th>Sending User</th>
            	<th>Receiving User</th>
                <th>Date of Transfer</th>
            </tr>
            <c:forEach var="transfers" items="${nftTransferred}"> 
                <tr style="text-align:center">
                    <td><c:out value="${transfers.userIdSeller}" /></td>
                    <td><c:out value="${transfers.userIdBuyer}" /></td>
                    <td><c:out value="${transfers.dateCompleted}" /></td>
				</tr>
				</c:forEach>
        </table>
        
        			<table border="1" cellpadding="6">
            <caption><h2>NFT sale history</h2></caption>
            <tr>
            	<th>Seller</th>
            	<th>Buyer</th>
                <th>Date of Sale</th>
            </tr>
            <c:forEach var="sales" items="${nftSold}"> 
                <tr style="text-align:center">
                    <td><c:out value="${sales.userIdSeller}" /></td>
                    <td><c:out value="${sales.userIdBuyer}" /></td>
                    <td><c:out value="${sales.dateCompleted}" /></td>
				</tr>
				</c:forEach>
        </table>
	</div>
		 </center>
		 </div>
	</body>
</html>