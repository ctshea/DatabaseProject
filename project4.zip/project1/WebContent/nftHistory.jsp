<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %> 
    
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>NFT History Page</title>
</head>
<center><h1>Showing your NFT history</h1> </center>
<div align="center">
	<body>
	 <center>
		 <a href="activitypage.jsp?"target ="_self" > Back to Homepage</a><br><br> 
    	<div align="center">
				         <table border="1" cellpadding="6">
            <caption><h2>List of NFTs you have minted</h2></caption>
            <tr>
                <th>NFT Name</th>
                <th>Description</th>
                <th>Image Url</th>
				<th>Date Minted</th>
            </tr>
      			<c:forEach var="mintedNfts" items="${mintedByUser}"> 
                <tr style="text-align:center">
                    <td><c:out value="${mintedNfts.name}" /></td>
                    <td><c:out value="${mintedNfts.description}" /></td>
                    <td><c:out value="${mintedNfts.image}" /></td>
                    <td><c:out value="${mintedNfts.dateMinted}" /></td>
             </c:forEach>
        </table>
				
                         <table border="1" cellpadding="6">
                    <caption><h2>List of NFTs you have sold</h2></caption>
            <tr>
                <th>NFT Name</th>
                <th>Sold to</th>
                <th>Date of Sale</th>
                <th>Sale Amount</th>
            </tr>
      			<c:forEach var="soldByUser" items="${soldByUser}"> 
                <tr style="text-align:center">
                    <td><c:out value="${soldByUser.nftName}" /></td>
                    <td><c:out value="${soldByUser.userTransaction}" /></td>
                    <td><c:out value="${soldByUser.dateCompleted}" /></td>
                    <td><c:out value="${soldByUser.cost}" /></td>
					</td>
             </c:forEach>
        </table>
        
                                 <table border="1" cellpadding="6">
                    <caption><h2>List of NFTs you have purchased</h2></caption>
            <tr>
                <th>NFT Name</th>
                <th>Purchase from</th>
                <th>Date of Purchase</th>
                <th>Purchase Amount</th>
            </tr>
      			<c:forEach var="purchasedByUser" items="${purchasedByUser}"> 
                <tr style="text-align:center">
                    <td><c:out value="${purchasedByUser.nftName}" /></td>
                    <td><c:out value="${purchasedByUser.userTransaction}" /></td>
                    <td><c:out value="${purchasedByUser.dateCompleted}" /></td>
                    <td><c:out value="${purchasedByUser.cost}" /></td>
					</td>
             </c:forEach>
        </table>
	</div>
		 </center>
		 </div>
	</body>
</html>