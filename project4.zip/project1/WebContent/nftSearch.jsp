<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %> 
    
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Users</title>
</head>
<center><h1>Search for Nfts</h1> </center>
<div align="center">
	<body>
	 <center>
		 <a href="activitypage.jsp?"target ="_self" > Back to Homepage</a><br><br> 
    	<div align="center">
     	<form action="nftSearch">
    	<table border="1" cellpadding="6">
    	    <caption><h2>Showing all Nfts, enter text below to search by name.</h2></caption>
            <tr>
					<th>Name: </th>
					<td align="center" colspan="3">
						<input type="text" name="name" size="50" value="Name" onfocus="this.value=''">
					</td>
				</tr>

					<tr>
					<td align="center" colspan="5">
						<input type="submit" name= "search" value="Search"/>
						<input type="submit" name = "reset" value="Reset Search"/>
					</td>
				</tr>
				</form>
				</table>
				
			<table border="1" cellpadding="6">
            <caption><h2>List of Nfts</h2></caption>
            <tr>
            	<th>Nft Name</th>
                <th>Nft Description</th>
                <th>Nft Image Url</th>
            </tr>
      			<c:forEach var="nfts" items="${nftList}">
                <tr style="text-align:center">
                    <td><c:out value="${nfts.name}" /></td>
                    <td><c:out value="${nfts.description}" /></td>
                    <td><c:out value="${nfts.image}" /></td>              
                    <td><form action="viewNft">
                   
                    <input type="hidden" name="nftName" value="${nfts.name}">
					<input type="submit" value="View Nft"/>
					</form></td>
             </c:forEach>
        </table>
	</div>
		 </center>
		 </div>
	</body>
</html>