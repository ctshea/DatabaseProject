<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
 <%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
 <%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
 
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Root page</title>
</head>
<body>

<div align = "center">
	
	<form action = "initialize">
		<input type = "submit" value = "Initialize the Database"/>
	</form>
	<a href="login.jsp"target ="_self" > logout</a><br><br> 

<h1>List all data</h1>
    <div align="center">
        <table border="1" cellpadding="6">
            <caption><h2>Big creators</h2></caption>
            <tr>
                <th>User email(s)</th>
                <th>NFTs created</th>
            </tr>
			<c:forEach var="bigCreators" items="${bigCreators}"> 
                <tr style="text-align:center">
                    <td><c:out value="${bigCreators.email}" /></td>
                    <td><c:out value="${bigCreators.count}" /></td>
             </c:forEach>
        </table>
	</div>
	    <div align="center">
        <table border="1" cellpadding="6">
            <caption><h2>Big sellers</h2></caption>
            <tr>
                <th>User email(s)</th>
                <th>NFTs sold</th>
            </tr>
			<c:forEach var="bigSellers" items="${bigSellers}"> 
                <tr style="text-align:center">
                    <td><c:out value="${bigSellers.email}" /></td>
                    <td><c:out value="${bigSellers.count}" /></td>
             </c:forEach>
        </table>
	</div>
		    <div align="center">
        <table border="1" cellpadding="6">
            <caption><h2>Big buyers</h2></caption>
            <tr>
                <th>User email(s)</th>
                <th>NFTs bought</th>
            </tr>
			<c:forEach var="bigBuyers" items="${bigBuyers}"> 
                <tr style="text-align:center">
                    <td><c:out value="${bigBuyers.email}" /></td>
                    <td><c:out value="${bigBuyers.count}" /></td>
             </c:forEach>
        </table>
	</div>
			    <div align="center">
        <table border="1" cellpadding="6">
            <caption><h2>Hot NFTs</h2></caption>
            <tr>
                <th>NFT name(s)</th>
                <th>Number of different owners</th>
            </tr>
			<c:forEach var="hotNfts" items="${hotNfts}"> 
                <tr style="text-align:center">
                    <td><c:out value="${hotNfts.name}" /></td>
                    <td><c:out value="${hotNfts.count}" /></td>
             </c:forEach>
        </table>
	</div>
	<caption><h2>Select users to see which NFTs they have both owned</h2></caption>
		<div align="center">
		<p> ${errorOne } </p>
		<form action="dropDownCompare">
        <table border="1" cellpadding="6">
            <tr>
                <th>User 1</th>
                <th>User 2</th>
            </tr> 
            <tr style="text-align:center">
            <td><select name ="user1">
            	<c:forEach var="users" items="${listUser}"> 
                     <option value="${users.email}">${users.email}</option>
                </c:forEach>
			</select></td>
            <td><select name ="user2">
            	<c:forEach var="users" items="${listUser}"> 
                     <option value="${users.email}">${users.email}</option>
                </c:forEach>
			</select></td>
            </tr>
            <tr>
            <td align="center" colspan="2"><input type="submit" value="Compare"/></td>
            </tr>
            <c:forEach var="nftsShared" items="${nftsShared}"> 
            	<tr style="text-align:center">
                     <td align="center" colspan="2"><c:out value="${nftsShared.name}" /></td>
           		 </tr>
            </c:forEach>
        </table>
        </form>
	</div>
			    <div align="center">
		<caption><h2>Diamond hands users, bought but never sold</h2></caption>
        <table border="1" cellpadding="6">
            <tr>
                <th>User name(s)</th>
            </tr>
			<c:forEach var="diamondHandsUsers" items="${diamondHandsUsers}"> 
                <tr style="text-align:center">
                    <td><c:out value="${diamondHandsUsers.email}" /></td>
             </c:forEach>
        </table>
	</div>
				    <div align="center">
		<caption><h2>Paper hands users, bought but sold all</h2></caption>
        <table border="1" cellpadding="6">
            <tr>
                <th>User name(s)</th>
            </tr>
			<c:forEach var="paperHandsUsers" items="${paperHandsUsers}"> 
                <tr style="text-align:center">
                    <td><c:out value="${paperHandsUsers.email}" /></td>
             </c:forEach>
        </table>
	</div>
			    <div align="center">
			                <caption><h2>Good buyers(purchased more than 3 NFTs)</h2></caption>
        <table border="1" cellpadding="6">
            <tr>
                <th>User email(s)</th>
                <th>NFTs bought</th>
            </tr>
			<c:forEach var="goodBuyers" items="${goodBuyers}"> 
                <tr style="text-align:center">
                    <td><c:out value="${goodBuyers.email}" /></td>
                    <td><c:out value="${goodBuyers.count}" /></td>
             </c:forEach>
        </table>
	</div>
				    <div align="center">
			                <caption><h2>Inactive users</h2></caption>
        <table border="1" cellpadding="6">
            <tr>
                <th>User email(s)</th>
            </tr>
			<c:forEach var="inactiveUsers" items="${inactiveUsers}"> 
                <tr style="text-align:center">
                    <td><c:out value="${inactiveUsers.email}" /></td>
             </c:forEach>
        </table>
	</div>
		<caption><h2>Select user to see their statistics</h2></caption>
		<div align="center">
		<p> ${errorOne } </p>
		<form action="userStatistics">
        <table border="1" cellpadding="6">
            <tr>
                <th colspan = "6">User</th>
            </tr> 
            <tr style="text-align:center">
            <td align="center" colspan="6"><select name ="user">
            	<c:forEach var="users" items="${listUser}"> 
                     <option value="${users.email}">${users.email}</option>
                </c:forEach>
			</select></td>
            </tr>
            <tr>
            <td align="center" colspan="6"><input type="submit" value="View stats"/></td>
            </tr>
            </form>
    		<tr>
    			<th>User</th>
    			<th>NFTs bought</th>
    			<th>NFTs sold</th>
    			<th>NFTs outgoing transfer</th>
    			<th>NFTs incoming transfer</th>
    			<th>NFTs currently owned</th>
    		</tr>
    		<tr>
    			<td><c:out value="${userStats.email}" /></td>
                <td><c:out value="${userStats.bought}" /></td>
                <td><c:out value="${userStats.sold}" /></td>
                <td><c:out value="${userStats.transferTo}" /></td>
                <td><c:out value="${userStats.transferFrom}" /></td>
                <td><c:out value="${userStats.userOwned}" /></td>
    		</tr>
        </table>
	</div>
    <div align="center">
        <table border="1" cellpadding="6">
            <caption><h2>List of Users</h2></caption>
            <tr>
                <th>Email</th>
                <th>First name</th>
                <th>Last name</th>
                <th>Address</th>
                <th>Password</th>
                <th>Birthday</th>
                <th>eth_bal($)</th>
            </tr>
			<c:forEach var="users" items="${listUser}"> 
                <tr style="text-align:center">
                     <td><c:out value="${users.email}" /></td>
                    <td><c:out value="${users.firstName}" /></td>
                    <td><c:out value="${users.lastName}" /></td>
                    <td><c:out value= "${users.adress_street_num} ${users.adress_street} ${users.adress_city} ${users.adress_state} ${users.adress_zip_code}" /></td>
                    <td><c:out value="${users.password}" /></td>
                    <td><c:out value="${users.birthday}" /></td>
                    <td><c:out value="${users.eth_bal}"/></td> 
             </c:forEach>
        </table>
	</div>
    <div align="center">
        <table border="1" cellpadding="6">
            <caption><h2>List of Nfts</h2></caption>
            <tr>
            	<th>ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Image</th>
                <th>Owner Email</th>
                <th>Listed</th>
                <th>Original Owner</th>
                <th>Date Minted</th>
            </tr>
            <c:forEach var="nfts" items="${listNft}">
                <tr style="text-align:center">
                	<td><c:out value="${nfts.nftid}" /></td>
                    <td><c:out value="${nfts.name}" /></td>
                    <td><c:out value="${nfts.description}" /></td>
                    <td><c:out value="${nfts.image}" /></td>
                    <td><c:out value="${nfts.userEmail}" /></td>
                    <td><c:out value="${nfts.listed}" /></td>
                    <td><c:out value="${nfts.originalOwner}" /></td>
                    <td><c:out value="${nfts.dateMinted}" /></td>
            </c:forEach>
        </table>
 	<div align="center">
        <table border="1" cellpadding="6">
            <caption><h2>List of Listings</h2></caption>
            <tr>
            	<th>Listings ID</th>
            	<th>NFT ID</th>
                <th>Duration(Days)</th>
                <th>Date Listed</th>
                <th>Cost</th>
                <th>Activity</th>
            </tr>
            <c:forEach var="listings" items="${listListings}">
                <tr style="text-align:center">
                    <td><c:out value="${listings.listingsid}" /></td>
                 	<td><c:out value="${listings.nftid}" /></td>
                    <td><c:out value="${listings.duration}" /></td>
                    <td><c:out value="${listings.dateListed}" /></td>
                    <td><fmt:formatNumber type="number" minFractionDigits="2" maxFractionDigits="2" value="${listings.cost}"/></td>
                    <td><c:out value="${listings.activeState}" /></td>
            </c:forEach>
        </table>
	</div> 
	<div align="center">
        <table border="1" cellpadding="6">
            <caption><h2>List of Transactions</h2></caption>
            <tr>
            	<th>Transactions ID</th>
            	<th>Receiver</th>
                <th>Sender</th>
                <th>Date Completed</th>
                <th>Transaction Type</th>
                <th>NFT ID</th>
                <th>Listings ID</th>
            </tr>
            <c:forEach var="transactions" items="${listTransactions}">
                <tr style="text-align:center">
                    <td><c:out value="${transactions.transactionid}" /></td>
                 	<td><c:out value="${transactions.userIdBuyer}" /></td>
                    <td><c:out value="${transactions.userIdSeller}" /></td>
                    <td><c:out value="${transactions.dateCompleted}" /></td>
                    <td><c:out value="${transactions.type}" /></td>
                    <td><c:out value="${transactions.nftid}" /></td>
                    <td><c:out value="${transactions.listingsid}" /></td>
            </c:forEach>
        </table>
	</div> 
	

</body>
</html>