import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.PreparedStatement;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
import java.sql.ResultSet;
//import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
/**
 * Servlet implementation class Connect
 */
@WebServlet("/nftDAO")
public class nftDAO 
{
	private static final long serialVersionUID = 1L;
	private Connection connect = null;
	private Statement statement = null;
	private PreparedStatement preparedStatement = null;
	private ResultSet resultSet = null;
	
	public nftDAO(){}
	
	/** 
	 * @see HttpServlet#HttpServlet()
     */
    protected void connect_func() throws SQLException {
    	//uses default connection to the database
        if (connect == null || connect.isClosed()) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                throw new SQLException(e);
            }
            connect = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/projectdb?allowPublicKeyRetrieval=true&useSSL=false&user=john&password=pass1234");
            System.out.println(connect);
        }
    }
    
    public boolean database_login(String email, String password) throws SQLException{
    	try {
    		connect_func("root","pass1234");
    		String sql = "select * from user where email = ?";
    		preparedStatement = connect.prepareStatement(sql);
    		preparedStatement.setString(1, email);
    		ResultSet rs = preparedStatement.executeQuery();
    		return rs.next();
    	}
    	catch(SQLException e) {
    		System.out.println("failed login");
    		return false;
    	}
    }
	//connect to the database 
    public void connect_func(String username, String password) throws SQLException {
        if (connect == null || connect.isClosed()) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                throw new SQLException(e);
            }
            connect = (Connection) DriverManager
  			      .getConnection("jdbc:mysql://127.0.0.1:3306/projectdb?allowPublicKeyRetrieval=true&"
  			          + "useSSL=false&user=" + username + "&password=" + password);
            System.out.println(connect);
        }
    }
    
    public List<nft> listAllNfts() throws SQLException {
        List<nft> listNft = new ArrayList<nft>();        
        String sql = "SELECT * FROM nft";      
        connect_func();      
        statement = (Statement) connect.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);
         
        while (resultSet.next()) {
        	int id = resultSet.getInt("nftid");
            String name = resultSet.getString("nftname");
            String description = resultSet.getString("nftdescription");
            String image = resultSet.getString("imagePath");
            String userEmail = resultSet.getString("userEmail");
            String listed = resultSet.getString("listed");  
            String originalOwner = resultSet.getString("originalOwner");  
            String dateMinted = resultSet.getString("dateMinted");
            
            nft nfts = new nft(id, name,description, image, userEmail, listed, originalOwner, dateMinted);
            listNft.add(nfts);
        }        
        resultSet.close();
        statement.close();
        disconnect();        
        return listNft;
    }
    
    protected void disconnect() throws SQLException {
        if (connect != null && !connect.isClosed()) {
        	connect.close();
        }
    }
    
    public void insert(nft nfts) throws SQLException {
    	//connect_func("root","pass1234");   
    	connect_func();

		String sql = "insert into Nft(nftname, nftdescription, imagePath, userEmail, listed, originalOwner, dateMinted) values (?, ?, ?, ?, ?, ?, ?)";
		preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
			preparedStatement.setString(1, nfts.getName());
			preparedStatement.setString(2, nfts.getDescription());
			preparedStatement.setString(3, nfts.getImage());
			preparedStatement.setString(4, nfts.getUserEmail());
			preparedStatement.setString(5, "n");
			preparedStatement.setString(6, nfts.getOriginalOwner());
			preparedStatement.setString(7, nfts.getDateMinted());

		preparedStatement.executeUpdate();
        preparedStatement.close();
    }
    
    public boolean delete(String name) throws SQLException {
        String sql = "DELETE FROM Nft WHERE nftname = ?";        
        connect_func();
        
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, name);
         
        boolean rowDeleted = preparedStatement.executeUpdate() > 0;
        preparedStatement.close();
        return rowDeleted;     
    }
     
    public boolean update(nft nfts) throws SQLException {
        String sql = "update Nft set userEmail= ? where nftid = ?";
        connect_func();

        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
		preparedStatement.setString(1, nfts.getUserEmail());
		preparedStatement.setInt(2, nfts.getNftid());
		
         
        boolean rowUpdated = preparedStatement.executeUpdate() > 0;
        preparedStatement.close();
        return rowUpdated;     
    }
    
    public boolean update(String newOwner, int nftid) throws SQLException {			//to easily change ownership
        String sql = "update Nft set userEmail= ? where nftid = ?";
        connect_func();

        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
		preparedStatement.setString(1, newOwner);
		preparedStatement.setInt(2, nftid);
		
         
        boolean rowUpdated = preparedStatement.executeUpdate() > 0;
        preparedStatement.close();
        
        update(nftid, "n");			//call other update to show it is no longer listed
        return rowUpdated;     
    }
    
    public boolean update(int nftId, String listStatus) throws SQLException {			//to update listed status
        String sql = "update Nft set listed= ? where nftid = ?";
        connect_func();
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
		preparedStatement.setString(1, listStatus);
		preparedStatement.setString(2, String.valueOf(nftId));
		
         
        boolean rowUpdated = preparedStatement.executeUpdate() > 0;
        preparedStatement.close();
        return rowUpdated;     
    }
    
    
    public boolean update() throws SQLException {			//to update listed status on init() for remaining listed NFTs
        String sql = "update Nft LEFT JOIN Listings on Nft.nftid = Listings.nftid set listed = ? WHERE activity = ?";
        connect_func();
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
		preparedStatement.setString(1, "y");
		preparedStatement.setString(2, "active");
		
         
        boolean rowUpdated = preparedStatement.executeUpdate() > 0;
        preparedStatement.close();
        return rowUpdated;     
    }
    
    public List<nft> searchAllNfts(String searchName) throws SQLException {
        List<nft> listNft = new ArrayList<nft>();        
        String sql = "SELECT nftname, nftDescription, imagePath, originalOwner FROM Nft where nftname like ?";      
        connect_func();          
        
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, "%" + searchName + "%");
        
        ResultSet resultSet = preparedStatement.executeQuery();
         
        while (resultSet.next()) {
            String name = resultSet.getString("nftname");
            String description = resultSet.getString("nftdescription");
            String url = resultSet.getString("imagePath");
            String originalOwner = resultSet.getString("originalOwner");
            
            nft nfts = new nft(name,description, url, originalOwner);
            listNft.add(nfts);
        }        
        resultSet.close();
        preparedStatement.close();
        disconnect();        
        return listNft;
    }
    
    public List<nft> getNft(String userEmail) throws SQLException {
    	List<nft> listNft = new ArrayList<nft>();
        //String sql = "SELECT distinct nft.nftid, nftname, nftdescription, imagePath, userEmail from Nft LEFT JOIN Listings on Nft.nftid = Listings.nftid WHERE userEmail = ?"
        //		+ " and not exists (select * from listings LEFT JOIN nft on listings.nftid = nft.nftid where userEmail = ? and activity = ?)";
    	String sql = "SELECT distinct nft.nftid, nftname, nftdescription, imagePath, originalOwner, dateMinted, userEmail from Nft LEFT JOIN Listings on Nft.nftid = Listings.nftid WHERE userEmail = ? and listed = ?";
    	
        connect_func();
         
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, userEmail);
        preparedStatement.setString(2, "n");
         
        ResultSet resultSet = preparedStatement.executeQuery();
         
        while (resultSet.next()) {
        	int id = resultSet.getInt("nftid");
            String name = resultSet.getString("nftname");
            String description = resultSet.getString("nftdescription");
            String image = resultSet.getString("imagePath");
            String email = resultSet.getString("userEmail");			
			String originalOwner = resultSet.getString("originalOwner"); String
			dateMinted = resultSet.getString("dateMinted");			
            nft nfts = new nft(id, name, description, image, email, "n", originalOwner, dateMinted);
            listNft.add(nfts);
        }
         
        resultSet.close();
        preparedStatement.close();
         
        return listNft;
    }
    
    public List<nft> getNftsMinted(String userEmail) throws SQLException {
    	List<nft> listNft = new ArrayList<nft>();
    	String sql = "select * from nft where originalOwner = ?";
    	
        connect_func();
         
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, userEmail);
         
        ResultSet resultSet = preparedStatement.executeQuery();
         
        while (resultSet.next()) {
        	int id = resultSet.getInt("nftid");
            String name = resultSet.getString("nftname");
            String description = resultSet.getString("nftdescription");
            String image = resultSet.getString("imagePath");
            String email = resultSet.getString("userEmail");			
			String originalOwner = resultSet.getString("originalOwner"); String
			dateMinted = resultSet.getString("dateMinted");			
            nft nfts = new nft(id, name, description, image, email, "n", originalOwner, dateMinted);
            listNft.add(nfts);
        }
         
        resultSet.close();
        preparedStatement.close();
         
        return listNft;
    }
    
    public List<nft> getHotNfts() throws SQLException {
    	List<nft> listNft = new ArrayList<nft>();
    	String sql = "select count(*), nftname from (select nftname, nft.nftid from nft inner join transactions"
    			+ " on nft.nftid = transactions.nftid where userEmailBuyer != originalOwner group by nft.nftid, userEmailBuyer) as count group by nftId "
    			+ "having count(*) = (select count(*) from (select nftname, nft.nftid from nft inner join transactions on nft.nftid = transactions.nftid "
    			+ "where userEmailBuyer != originalOwner group by nft.nftid, userEmailBuyer) as count group by nftId order by count(*) desc limit 1)";
    	
        connect_func();
        
    	statement = (Statement) connect.createStatement();
    	ResultSet resultSet = statement.executeQuery(sql);
  
        while (resultSet.next()) {
        	int count = resultSet.getInt("count(*)") + 1;		//plus one for original owner
            String name = resultSet.getString("nftname");		
            nft nfts = new nft(count, name);
            listNft.add(nfts);
        }
         
        resultSet.close();
        statement.close();
        return listNft;
    }
    public List<nft> getCommonNfts(String name1, String name2) throws SQLException {
    	List<nft> listNft = new ArrayList<nft>();
    	String sql = "select distinct nft.nftname from nft inner join transactions on nft.nftid = transactions.nftid where (originalOwner = ? or userEmailBuyer = ?)"
    			+ " and (originalOwner = ? or userEmailBuyer = ?)";
    	
        connect_func();
        
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, name1);
        preparedStatement.setString(2, name1);
        preparedStatement.setString(3, name2);
        preparedStatement.setString(4, name2);
         
        ResultSet resultSet = preparedStatement.executeQuery();
         
  
        while (resultSet.next()) {
            String name = resultSet.getString("nftname");		
            nft nfts = new nft(name);
            listNft.add(nfts);
        }
         
        resultSet.close();
        preparedStatement.close();
        return listNft;
    }
    public nft getSingleNft(String nftname) throws SQLException {
    	nft nfts = null;
        String sql = "SELECT * FROM Nft WHERE nftname = ?";
         
        connect_func();
         
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, nftname);
         
        ResultSet resultSet = preparedStatement.executeQuery();
         
        while (resultSet.next()) {
        	int id = resultSet.getInt("nftid");
            String name = resultSet.getString("nftname");
            String description = resultSet.getString("nftdescription");
            String image = resultSet.getString("imagePath");
            String email = resultSet.getString("userEmail");  
            String listed = resultSet.getString("listed");  
            String originalOwner = resultSet.getString("originalOwner");  
            String dateMinted = resultSet.getString("dateMinted");
            nfts = new nft(id, name, description, image, email, listed, originalOwner, dateMinted);
        }
         
        resultSet.close();
        preparedStatement.close();
         
        return nfts;
    }
    
    public List<nft> getUserNfts(String userEmail) throws SQLException {
    	List<nft> listNft = new ArrayList<nft>();
    	String sql = "select * from nft where userEmail = ?";
    	
        connect_func();
         
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, userEmail);
         
        ResultSet resultSet = preparedStatement.executeQuery();
         
        while (resultSet.next()) {
        	int id = resultSet.getInt("nftid");
            String name = resultSet.getString("nftname");
            String description = resultSet.getString("nftdescription");
            String image = resultSet.getString("imagePath");
            String email = resultSet.getString("userEmail");    
            String originalOwner = resultSet.getString("originalOwner");  
            String dateMinted = resultSet.getString("dateMinted");
            nft nfts = new nft(id, name, description, image, email, "n", originalOwner, dateMinted);
            listNft.add(nfts);
        }
         
        resultSet.close();
        preparedStatement.close();
        return listNft;
    }
    

    public boolean checkNftName(String name) throws SQLException  {
    	boolean checks = false;
    	String sql = "SELECT * FROM Nft WHERE nftname = ?";
    	connect_func();
    	preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, name);
        ResultSet resultSet = preparedStatement.executeQuery();
       
        
        if (resultSet.next()) {
        	checks = true;
        }
        preparedStatement.close();
    	return checks;
    }
    public boolean checkNftImagePath(String imagePath) throws SQLException  {
    	boolean checks = false;
    	String sql = "SELECT * FROM Nft WHERE imagePath = ?";
    	connect_func();
    	preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, imagePath);
        ResultSet resultSet = preparedStatement.executeQuery();
        
        if (resultSet.next()) {
        	checks = true;
        }
        preparedStatement.close();
    	return checks;
    }
    
    
    
    public void init() throws SQLException, FileNotFoundException, IOException{
    	connect_func();
        statement =  (Statement) connect.createStatement();
        
        String[] INITIAL = {"use projectdb; ",
					        "drop table if exists Nft; ",
					        ("CREATE TABLE if not exists Nft( " +
					            "nftid int auto_increment NOT NULL UNIQUE," + 
					            "nftname VARCHAR(30) NOT NULL UNIQUE, " +
					            "nftdescription VARCHAR(70) NOT NULL," +
					            "imagePath VARCHAR(250) NOT NULL UNIQUE," +
					            "userEmail VARCHAR(50) NOT NULL," +
					            "listed ENUM('y', 'n') NOT NULL," +
					            "originalOwner VARCHAR(50) NOT NULL," +
					            "dateMinted DATE NOT NULL, " +
					            "PRIMARY KEY (nftid) "+"); ")
        					};
        String[] TUPLES = {("insert into Nft(nftname, nftdescription, imagePath, userEmail, listed, originalOwner, dateMinted)"+
        			"values ('dog', 'dog with an eyepatch', 'https://preview.redd.it/l4jzph3tc5z71.jpg?auto=webp&s=a89013de52f194e2bb2cdf95284cde222654c965', 'jeannette@gmail.com', 'n', 'jeannette@gmail.com','2022-07-01'),"
        			+ "		('eye', 'eyeball and stairs', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSouf5VBg6B0dsD_pzuhX3j4U42EozNN-eyhA&usqp=CAU', 'ashley@gmail.com', 'n' ,'ashley@gmail.com','2022-07-01'),"
        			+ "		('person', 'person drawn in paint', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSB7hRaz5q1seXRoxW-AN4Ptr0d-Ikdc9lquQ&usqp=CAU', 'jeannette@gmail.com', 'n' , 'jeannette@gmail.com','2022-07-01'),"
        			+ "		('horses', 'multiple horse NFTs', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRrlBxUzPoJBBNgT15vC_z9iW3HirotMOgesQ&usqp=CAU', 'cody@gmail.com', 'n' , 'cody@gmail.com','2022-07-01'),"
        			+ "		('pelicans', 'multiple pelican NFTs', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQouK6aSiMxxJa6IaDFFeSMAhYkyw7lzidphA&usqp=CAU', 'rudy@gmail.com', 'n', 'rudy@gmail.com','2022-07-01'),"
        			+ "		('coin', 'crypto on a skyscraper', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSmGr0jVq6xiRcHgIXt8ACv1r7Ojx1VSVJNrQ&usqp=CAU', 'angelo@gmail.com', 'n', 'angelo@gmail.com','2022-07-01'),"
        			+ "		('robot', 'robot standing', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQCE3l1dw0l3bYj_s6hKn-J2kvgCc9Mpto5yA&usqp=CAU', 'sophie@gmail.com', 'n', 'sophie@gmail.com','2022-07-01'),"
        			+ "		('cat', 'fashionable cat', 'https://moon.ly/blog/content/images/2022/03/252.png', 'cody@gmail.com', 'n', 'cody@gmail.com','2022-07-01'),"
        			+ "		('clothed coin', 'coin with a hoodie', 'https://metav.rs/assets/uploads/2022/08/fake-NFTs.webp', 'sophie@gmail.com', 'n', 'sophie@gmail.com','2022-07-01'),"
        			+ "		('psychedelic cat', 'smoking cat with psychedelic background', 'https://miro.medium.com/max/1024/0*DFBQ7dyFQWRaOMkV.png', 'susie@gmail.com', 'n', 'susie@gmail.com','2022-07-01');")
			    			};
        
        //for loop to put these in database
        for (int i = 0; i < INITIAL.length; i++)
        	statement.execute(INITIAL[i]);
        for (int i = 0; i < TUPLES.length; i++)	
        	statement.execute(TUPLES[i]);
        statement.close();
        disconnect();
    }
    
   
    
    
    
    
    
	
	

}
