import java.math.BigDecimal;
import java.math.RoundingMode;

public class user 
{
		protected String password;
	 	protected String email;
	    protected String firstName;
	    protected String lastName;
	    protected String adress_street_num;
	    protected String adress_street;
	    protected String adress_city;
	    protected String adress_state;
	    protected String adress_zip_code;
	    protected String birthday;
	    protected BigDecimal eth_bal;
	 
	    protected int count;
	    
	    //to see statistics for each user
	    protected int bought;
	    protected int sold;
	    protected int transferTo;
	    protected int transferFrom;
	    protected int userOwned;
	    //constructors
	    public user() {
	    }
	    
	    public user(String email, int count) {	//object for big creator/big seller/big buyer
	    	this.email = email;
	    	this.count = count;
	    }
	    
	    public user(String email, int bought, int sold, int transferTo, int transferFrom, int userOwned) {
	    	this.email = email;
	    	this.bought = bought;
	    	this.sold = sold;
	    	this.transferTo = transferTo;
	    	this.transferFrom = transferFrom;
	    	this.userOwned = userOwned;
	    }
	    
	    public user(String email, String firstName, String lastName) 
	    {
	        this.email = email;
	        this.firstName = firstName;
	        this.lastName = lastName;
	    }
	    
	    public user(String email) 
	    {
	        this.email = email;
	    }
	    
	    public user(String email,String firstName, String lastName, String password,String birthday, String adress_street_num, String adress_street, String adress_city, String adress_state,String adress_zip_code, BigDecimal eth_bal) 
	    {
	    	this(firstName,lastName,password,birthday, adress_street_num,  adress_street,  adress_city,  adress_state,  adress_zip_code,eth_bal);
	    	this.email = email;
	    }
	 
	
	    public user(String firstName, String lastName, String password,String birthday, String adress_street_num, String adress_street, String adress_city, String adress_state,String adress_zip_code, BigDecimal eth_bal) 
	    {
	    	this.firstName = firstName;
	    	this.lastName = lastName;
	    	this.password = password;
	        this.birthday = birthday;
	        this.adress_street_num = adress_street_num;
	        this.adress_street = adress_street;
	        this.adress_city= adress_city;
	        this.adress_state = adress_state;
	        this.adress_zip_code = adress_zip_code;
	        this.eth_bal = eth_bal;
	    }
	    
	   //getter and setter methods
	    public String getEmail() {
	        return email;
	    }
	    public void setEmail(String email) {
	        this.email = email;
	    }
	    
	    public String getFirstName() {
	        return firstName;
	    }
	    public void setFirstName(String firstName) {
	        this.firstName = firstName;
	    }
	    
	    public String getLastName() {
	        return lastName;
	    }
	    public void setLastName(String lastName) {
	        this.lastName = lastName;
	    }
	    
	    public String getPassword() {
	        return password;
	    }
	    public void setPassword(String password) {
	        this.password = password;
	    }
	  
	    public String getBirthday() {
	    	return birthday;
	    }
	    public void setBirthday(String birthday) {
	    	this.birthday = birthday;
	    }
	    
	    public String getAdress_street_num() {
	        return adress_street_num;
	    }
	    public void setAdress_street_num(String adress_street_num) {
	        this.adress_street_num = adress_street_num;
	    }
	    public String getAdress_street() {
	        return adress_street;
	    }
	    public void setAdress_street(String adress_street) {
	        this.adress_street = adress_street;
	    }
	    public String getAdress_city() {
	        return adress_city;
	    }
	    public void setAdress_city(String adress_city) {
	        this.adress_city = adress_city;
	    }
	    public String getAdress_state() {
	        return adress_state;
	    }
	    public void setAdress_state(String adress_state) {
	        this.adress_state = adress_state;
	    }
	    public String getAdress_zip_code() {
	        return adress_zip_code;
	    }
	    public void setAdress_zip_code(String adress_zip_code) {
	        this.adress_zip_code = adress_zip_code;
	    }
	    
	    public BigDecimal getEth_bal() {
	    	eth_bal = eth_bal.setScale(2, RoundingMode.UP);
	    	return eth_bal;
	    }
	    public void setEth_bal(BigDecimal eth_bal) {
	    	this.eth_bal = eth_bal;
	    }
	    public int getCount() {
	    	return count;
	    }
	    public void setCount(int count) {
	    	this.count = count;
	    }
	    public int getBought() {
	    	return bought;
	    }
	    public void setBought(int bought) {
	    	this.bought = bought;
	    }
	    public void setSold(int sold) {
	    	this.sold = sold;
	    }
	    public int getSold() {
	    	return sold;
	    }
	    public void setTransferTo(int transferTo) {
	    	this.transferTo = transferTo;
	    }
	    public int getTransferTo() {
	    	return transferTo;
	    }
	    public void setTransferFrom(int transferFrom) {
	    	this.transferFrom = transferFrom;
	    }
	    public int getTransferFrom() {
	    	return transferFrom;
	    }
	    public void setUserOwned(int userOwned) {
	    	this.userOwned = userOwned;
	    }
	    public int getUserOwned() {
	    	return userOwned;
	    }

	}