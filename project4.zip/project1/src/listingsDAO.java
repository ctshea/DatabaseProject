import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.time.temporal.Temporal;
import java.time.format.DateTimeFormatter;
import java.sql.PreparedStatement;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
import java.sql.ResultSet;
//import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
/**
 * Servlet implementation class Connect
 */
@WebServlet("/listingsDAO")
public class listingsDAO 
{
	private static final long serialVersionUID = 1L;
	private Connection connect = null;
	private Statement statement = null;
	private PreparedStatement preparedStatement = null;
	private ResultSet resultSet = null;
	
	public listingsDAO(){}
	
	/** 
	 * @see HttpServlet#HttpServlet()
     */
    protected void connect_func() throws SQLException {
    	//uses default connection to the database
        if (connect == null || connect.isClosed()) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                throw new SQLException(e);
            }
            connect = (Connection) DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/projectdb?allowPublicKeyRetrieval=true&useSSL=false&user=john&password=pass1234");
            System.out.println(connect);
        }
    }
    
    public boolean database_login(String email, String password) throws SQLException{
    	try {
    		connect_func("root","pass1234");
    		String sql = "select * from user where email = ?";
    		preparedStatement = connect.prepareStatement(sql);
    		preparedStatement.setString(1, email);
    		ResultSet rs = preparedStatement.executeQuery();
    		return rs.next();
    	}
    	catch(SQLException e) {
    		System.out.println("failed login");
    		return false;
    	}
    }
	//connect to the database 
    public void connect_func(String username, String password) throws SQLException {
        if (connect == null || connect.isClosed()) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e) {
                throw new SQLException(e);
            }
            connect = (Connection) DriverManager
  			      .getConnection("jdbc:mysql://127.0.0.1:3306/userdb?"
  			          + "useSSL=false&user=" + username + "&password=" + password);
            System.out.println(connect);
        }
    }
    
    public List<listings> listAllListings() throws SQLException {
        List<listings> listListings = new ArrayList<listings>();        
        String sql = "SELECT * FROM Listings";      
        connect_func();      
        statement = (Statement) connect.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);
         
        while (resultSet.next()) {
        	int listingsid = resultSet.getInt("listingsid");
        	int id = resultSet.getInt("nftid");
            int duration = resultSet.getInt("durationDays");
            String dateListed = resultSet.getString("dateListed");
            double cost = resultSet.getDouble("cost");
            BigDecimal costFormatted = new BigDecimal(cost);
            String activity = resultSet.getString("activity");     
            listings newListings = new listings(listingsid, id,duration, dateListed, costFormatted, activity);
            listListings.add(newListings);
        }        
        resultSet.close();
        statement.close();
        disconnect();        
        return listListings;
    }
    
    public List<listings> listAllUserListings(String userName) throws SQLException {
        List<listings> listListings = new ArrayList<listings>();        
        String sql = "SELECT * FROM Listings INNER JOIN Nft ON Listings.nftid=Nft.nftid WHERE userEmail = ? AND activity = ?";      
        connect_func();      
        
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, userName);
        preparedStatement.setString(2, "active");
        
        ResultSet resultSet = preparedStatement.executeQuery();
         
        while (resultSet.next()) {
        	int nftid = resultSet.getInt("nftid");
        	String nftname= resultSet.getString("nftname");
            int duration = resultSet.getInt("durationDays");
            String dateListed = resultSet.getString("dateListed");
            double cost = resultSet.getDouble("cost");
            BigDecimal costFormatted = new BigDecimal(cost);
            costFormatted = costFormatted.setScale(2, RoundingMode.UP);
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate dateList = LocalDate.parse(dateListed, dtf);
            LocalDateTime currentDate = LocalDateTime.now();
            int days = (int)ChronoUnit.DAYS.between(dateList, currentDate);
            int daysRemaining = duration - days;
            listings newListings = new listings(nftid, nftname, duration, daysRemaining, costFormatted);
            listListings.add(newListings);
        }        
        resultSet.close();
        preparedStatement.close();
        disconnect();        
        return listListings;
    }
    
    public List<listings> listAllActiveListings(String userName) throws SQLException {
        List<listings> listListings = new ArrayList<listings>();        
        String sql = "SELECT * FROM Listings INNER JOIN Nft ON Listings.nftid=Nft.nftid WHERE userEmail != ? AND activity = ?";      
        connect_func();      
        
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, userName);
        preparedStatement.setString(2, "active");
        
        ResultSet resultSet = preparedStatement.executeQuery();
         
        while (resultSet.next()) {
        	int listingsId = resultSet.getInt("listingsid");
        	int nftid = resultSet.getInt("nftid");
        	String nftname= resultSet.getString("nftname");
        	String description = resultSet.getString("nftdescription");
        	String imagePath = resultSet.getString("imagePath");
            int duration = resultSet.getInt("durationDays");
            String dateListed = resultSet.getString("dateListed");
            String seller = resultSet.getString("userEmail");
            double cost = resultSet.getDouble("cost");
            BigDecimal costFormatted = new BigDecimal(cost);
            costFormatted = costFormatted.setScale(2, RoundingMode.UP);
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate dateList = LocalDate.parse(dateListed, dtf);
            LocalDateTime currentDate = LocalDateTime.now();
            int days = (int)ChronoUnit.DAYS.between(dateList, currentDate);
            int daysRemaining = duration - days;
            listings newListings = new listings(listingsId, nftid, nftname, description, imagePath, duration, daysRemaining, costFormatted, seller);
            listListings.add(newListings);
        }        
        resultSet.close();
        preparedStatement.close();
        disconnect();        
        return listListings;
    }
    
    public List<listings> listAllSearchedListings(String userName, String searchName) throws SQLException {
        List<listings> listListings = new ArrayList<listings>();        
        String sql = "SELECT * FROM Listings INNER JOIN Nft ON Listings.nftid=Nft.nftid WHERE (userEmail != ? AND activity = ?) and nftname like ?";      
        connect_func();      
        
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, userName);
        preparedStatement.setString(2, "active");
        preparedStatement.setString(3, "%" + searchName + "%");
        
        ResultSet resultSet = preparedStatement.executeQuery();
         
        while (resultSet.next()) {
        	int listingsId = resultSet.getInt("listingsid");
        	int nftid = resultSet.getInt("nftid");
        	String nftname= resultSet.getString("nftname");
        	String description = resultSet.getString("nftdescription");
        	String imagePath = resultSet.getString("imagePath");
            int duration = resultSet.getInt("durationDays");
            String dateListed = resultSet.getString("dateListed");
            String seller = resultSet.getString("userEmail");
            double cost = resultSet.getDouble("cost");
            BigDecimal costFormatted = new BigDecimal(cost);
            costFormatted = costFormatted.setScale(2, RoundingMode.UP);
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate dateList = LocalDate.parse(dateListed, dtf);
            LocalDateTime currentDate = LocalDateTime.now();
            int days = (int)ChronoUnit.DAYS.between(dateList, currentDate);
            int daysRemaining = duration - days;
            listings newListings = new listings(listingsId, nftid, nftname, description, imagePath, duration, daysRemaining, costFormatted, seller);
            listListings.add(newListings);
        }        
        resultSet.close();
        preparedStatement.close();
        disconnect();        
        return listListings;
    }
    
    protected void disconnect() throws SQLException {
        if (connect != null && !connect.isClosed()) {
        	connect.close();
        }
    }
    
    public void insert(listings listings) throws SQLException {
    	//connect_func("root","pass1234");       
    	connect_func();
		String sql = "insert into Listings(nftid, durationDays, dateListed, cost, activity) values (?, ?, ?, ?, ?)";
		preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
			preparedStatement.setString(1, String.valueOf(listings.getNftid()));
			preparedStatement.setString(2, String.valueOf(listings.getDuration()));
			preparedStatement.setString(3, listings.getDateListed());
			preparedStatement.setString(4, String.valueOf(listings.getCost()));
			preparedStatement.setString(5, listings.getActiveState());

		preparedStatement.executeUpdate();
        preparedStatement.close();
    }
    
    public boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM Listings WHERE nftid = ?";        
        connect_func();
         
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, String.valueOf(id));
         
        boolean rowDeleted = preparedStatement.executeUpdate() > 0;
        preparedStatement.close();
        return rowDeleted;     
    }
     
    public boolean update(listings listings) throws SQLException {
        String sql = "update Listings set activity=? where listingsid = ?";
        connect_func();
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, listings.getActiveState());
		preparedStatement.setString(2, String.valueOf(listings.getListingsid()));
         
        boolean rowUpdated = preparedStatement.executeUpdate() > 0;
        preparedStatement.close();
        return rowUpdated;     
    }
    
    public boolean update(int nftid, String activity) throws SQLException {				//overloaded to easily change activity in listings
        String sql = "update Listings set activity=? where nftid = ?";
        connect_func();
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, activity);
		preparedStatement.setString(2, String.valueOf(nftid));
         
        boolean rowUpdated = preparedStatement.executeUpdate() > 0;
        System.out.println(rowUpdated);
        preparedStatement.close();
        return rowUpdated;     
    }
    
    public listings getListings(int nftid) throws SQLException {
    	listings listings = null;
        String sql = "SELECT * FROM Listings WHERE nftid = ?";
         
        connect_func();
         
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, String.valueOf(nftid));
         
        ResultSet resultSet = preparedStatement.executeQuery();
         
        if (resultSet.next()) {
        	int listingsid = resultSet.getInt("listingsid");
        	int nftids = resultSet.getInt("nftid");
            int duration = resultSet.getInt("durationDays");
            String dateListed = resultSet.getString("dateListed");
            double cost = resultSet.getDouble("cost");
            BigDecimal costFormatted = new BigDecimal(cost);
            String activity = resultSet.getString("activity");
            listings = new listings(listingsid, nftids, duration, dateListed, costFormatted, activity);
        }
         
        resultSet.close();
        preparedStatement.close();
         
        return listings;
    }
    
    
    public void updateListingStatus() throws SQLException{   
        String sql = "SELECT * FROM Listings where activity = ?";      
        connect_func();      
        preparedStatement = (PreparedStatement) connect.prepareStatement(sql);
        preparedStatement.setString(1, "active");
         
        ResultSet resultSet = preparedStatement.executeQuery();
        
         
        while (resultSet.next()) {
        	int listingid = resultSet.getInt("listingsid");
            int nftid = resultSet.getInt("nftid");
            int duration = resultSet.getInt("durationDays");
            double cost = resultSet.getDouble("cost");
            BigDecimal costFormatted = new BigDecimal(cost);
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			LocalDateTime currentDate = LocalDateTime.now();
            String dateListed = resultSet.getString("dateListed");
            LocalDate dateList = LocalDate.parse(dateListed, dtf);
            String activity = resultSet.getString("activity");
            int days = (int)ChronoUnit.DAYS.between(dateList, currentDate);
            if (days > duration && !activity.equals("sold")) {		//if expired, change active status
            	listings listing = new listings(listingid, nftid, duration, dateListed, costFormatted, "expired");
            	update(listing);
            }
        }
        preparedStatement.close();
    }
    
    public void init() throws SQLException, FileNotFoundException, IOException{
    	connect_func();
        statement =  (Statement) connect.createStatement();
        
        String[] INITIAL = {"use projectdb; ",
					        "drop table if exists Listings; ",
					        ("CREATE TABLE if not exists Listings( " +
					            "listingsid int auto_increment NOT NULL UNIQUE, " + 
					            "nftid int NOT NULL, " +
					            "durationDays int NOT NULL, " +
					            "dateListed DATE NOT NULL, " +
					            "cost DECIMAL(13,2) NOT NULL," +
					            "activity ENUM('active', 'sold', 'expired', 'cancelled') NOT NULL," +
					            "PRIMARY KEY (listingsid) "+"); ")
        					};
        String[] TUPLES = {("insert into Listings(nftid, durationDays, dateListed, cost, activity)"+
        			"values ('3', '60', '2022-09-27', '50.00', 'sold'),"
        			+ "('2', '30', '2022-09-20', '100.00', 'active'),"
        			+ "		('1', '90', '2022-08-20', '75.99', 'active'),"
        			+ "     ('5', '30', '2022-08-28', '150.50', 'active'),"		//expired
        			+ "     ('6', '30', '2022-10-05', '2000.00', 'active'),"
        			+ "     ('7', '60', '2022-07-15', '20.50', 'active'),"			//expired
        			+ "     ('9', '90', '2022-10-05', '5.99', 'active'),"
        			+ "     ('10', '30', '2022-10-10', '100.00', 'sold'),"
        			+ "     ('4', '60', '2022-09-18', '80.50', 'active'),"
        			+ "     ('8', '60', '2022-09-15', '89.99', 'sold');")
			    			};
        
        //for loop to put these in database
        for (int i = 0; i < INITIAL.length; i++)
        	statement.execute(INITIAL[i]);
        for (int i = 0; i < TUPLES.length; i++)	
        	statement.execute(TUPLES[i]);
        updateListingStatus();
        statement.close();
        disconnect();
    }
    
    
   
    
    
    
    
    
	
	

}
