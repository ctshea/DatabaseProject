public class nft 
{
		protected int nftid;
		protected String name;
	    protected String description;
	    protected String image;
	    protected String userEmail;
	    protected String listed;
	    protected String dateMinted;
	    protected String originalOwner;
	    
	    protected int count;
	 
	    //constructors
	    public nft() {
	    }
	 
	    public nft(int count, String name) {		//this is object for hot nfts part 4
	    	this.count = count;
	    	this.name = name;
	    }
	    
	    public nft(String name) {		//this is object for common nfts part 4
	    	this.name = name;
	    }
	    
	    public nft(String name, String description, String image,String userEmail, String listed, String originalOwner, String dateMinted) 
	    {
	    	this.name = name;
	    	this.description = description;
	    	this.image = image;
	    	this.userEmail = userEmail;
	    	this.listed = listed;
	    	this.dateMinted	= dateMinted;
	    	this.originalOwner = originalOwner;
	    }
	    public nft(int ID, String name, String description, String image,String userEmail, String listed, String originalOwner, String dateMinted) 
	    {
	    	this.nftid = ID;
	    	this.name = name;
	    	this.description = description;
	    	this.image = image;
	    	this.userEmail = userEmail;
	    	this.listed = listed;
	    	this.dateMinted	= dateMinted;
	    	this.originalOwner = originalOwner;
	    }
	    public nft(String name, String description, String image, String originalOwner) 
	    {
	    	this.name = name;
	    	this.description = description;
	    	this.image = image;
	    	this.originalOwner = originalOwner;
	    }
	    
	   //getter and setter methods
	 	public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		public String getImage() {
			return image;
		}

		public void setImage(String image) {
			this.image = image;
		}

		public String getUserEmail() {
			return userEmail;
		}

		public void setUserEmail(String userEmail) {
			this.userEmail = userEmail;
		}
		public int getNftid( ) {
			return nftid;
		}
		public void setListed(String listed) {
			this.listed = listed;
		}
		public String getListed() {
			return listed;
		}
		public void setDateMinted(String dateMinted) {
			this.dateMinted = dateMinted;
		}
		public String getDateMinted( ) {
			return dateMinted;
		}
		public void setOriginalOwner(String originalOwner) {
			this.originalOwner = originalOwner;
		}
		public String getOriginalOwner() {
			return originalOwner;
		}
		public void setCount(int count) {
			this.count = count;
		}
		public int getCount() {
			return count;
		}
	}