<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %> 
    
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Transfer page</title>
</head>
<center><h1>Transfer an NFT</h1> </center>
<div align="center">
	<body>
	 <center>
		 <a href="activitypage.jsp?"target ="_self" > Back to Homepage</a><br><br> 
    	<div align="center">
    	<form action="transfer">
    	<input type="hidden" name="nftname" value="<%= request.getParameter("nftname") %>">
    	<table border="1" cellpadding="6">
    	    <caption><h2>Enter user to transfer <%= request.getParameter("nftname") %> to.</h2></caption>
    	     		<p> ${errorOne } </p>
            <tr>
					<th>User email: </th>
					<td align="center" colspan="3">
						<input type="text" name="name" size="50" value="User Email" onfocus="this.value=''">
					</td>
				</tr>
					<tr>
					<td align="center" colspan="5">
						<input type="submit" value="Transfer"/>
					</td>
				</tr>
				</table>
				</form>
	</div>
		 </center>
		 </div>
	</body>
</html>