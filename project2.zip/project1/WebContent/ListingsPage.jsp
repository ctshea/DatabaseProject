<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %> 
    
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Listings</title>
</head>
<center><h1>List an NFT</h1> </center>
<div align="center">
	<body>
	 <center>
		 <a href="activitypage.jsp?"target ="_self" > Back to Homepage</a><br><br> 
    	<div align="center">
     	<form action="nftSearch">
    	<table border="1" cellpadding="6">
    	 <caption><h2><c:out value="Your eth balance: ${user.eth_bal}"/></h2></caption>
    	    <caption><h2>Showing all active listings, enter text below to search by name.</h2></caption>
    	    		<p> ${errorOne } </p>
            <tr>
					<th>Name: </th>
					<td align="center" colspan="3">
						<input type="text" name="name" size="50" value="Name" onfocus="this.value=''">
					</td>
				</tr>

					<tr>
					<td align="center" colspan="5">
						<input type="submit" name= "search" value="Search"/>
						<input type="submit" name = "reset" value="Reset Search"/>
					</td>
				</tr>
				</form>
				</table>
				
				         <table border="1" cellpadding="6">
				         <p> ${errorOne } </p>
            <caption><h2>All Actively Listed NFTs Available to Purchase</h2></caption>
            <tr>
            	<th>Nft ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Image Url</th>
                <th>Duration(days)</th>
                <th>Days Remaining</th>
                <th>Cost(eth)</th>
                <th>Seller</th>
            </tr>
      			<c:forEach var="listedNfts" items="${listedNfts}"> 
                <tr style="text-align:center">
                    <td><c:out value="${listedNfts.nftid}" /></td>
                    <td><c:out value="${listedNfts.nftName}" /></td>
                    <td><c:out value="${listedNfts.description}" /></td>
                    <td><a href = "${listedNfts.imagePath}"><c:out value="${listedNfts.imagePath}" /></a></td>
                    <td><c:out value="${listedNfts.duration}" /></td>
                    <td><c:out value="${listedNfts.daysRemaining}" /></td>
                    <td><c:out value="${listedNfts.cost}" /></td> 
                    <td><c:out value="${listedNfts.seller}" /></td> 
                    <td><form action="purchaseNft">
                    <input type="hidden" name="currentBalance" value="${user.eth_bal}">
                    <input type="hidden" name="cost" value="${listedNfts.cost}">
                    <input type="hidden" name="seller" value="${listedNfts.seller}">
                    <input type="hidden" name="listingsid" value="${listedNfts.listingsid}">
                    <input type="hidden" name="nftid" value="${listedNfts.nftid}">
						<input type="submit" value="Purchase"/>
					</form></td>
             </c:forEach>
        </table>
                         <table border="1" cellpadding="6">
                    <caption><h2>Your Listed NFTs</h2></caption>
            <tr>
            	<th>Nft ID</th>
                <th>Name</th>
                <th>Duration</th>
                <th>Days Remaining</th>
                <th>Amount</th>
            </tr>
      			<c:forEach var="listedUserNfts" items="${listedUserNfts}"> 
                <tr style="text-align:center">
                    <td><c:out value="${listedUserNfts.nftid}" /></td>
                    <td><c:out value="${listedUserNfts.nftName}" /></td>
                    <td><c:out value="${listedUserNfts.duration}" /></td>
                    <td><c:out value="${listedUserNfts.daysRemaining}" /></td>
                    <td><c:out value="${listedUserNfts.cost}" /></td>
              		<td align="center" colspan="5">
                    <form action="delisting">
                        <input type="hidden" name="nftid" value="${listedUserNfts.nftid}">
						<input type="submit" value="De-list"/>
					</form>
					</td>
             </c:forEach>
        </table>
	</div>
		 </center>
		 </div>
	</body>
</html>