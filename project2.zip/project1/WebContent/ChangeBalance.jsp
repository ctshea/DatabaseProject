<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %> 
    
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Change Balance page</title>
</head>
<center><h1>Add or remove Eth from your account</h1> </center>
<div align="center">
	<body>
	 <center>
		 <a href="activitypage.jsp?"target ="_self" > Back to Homepage</a><br><br> 
    	<div align="center">
    	<form action="changeEth">
    	<input type="hidden" name="currentBalance" value="${user.eth_bal}">
    	<caption><h2>Your current eth balance</h2></caption>
        <table border="1" cellpadding="6">
            <tr>
                <th>balance(eth): 
                <c:out value="${user.eth_bal}"/></th>
            </tr>
    	<table border="1" cellpadding="6">
    	    <caption><h2>Enter amount of eth to add or remove to/from your account balance.</h2></caption>
    	    		<p> ${errorOne } </p>
    	    		<p> ${errorTwo } </p>
    	    		<p> ${errorThree } </p>
            <tr>
            
					<th>Amount to add/remove(eth): </th>
					<td align="center" colspan="3">
						<input type="text" name="ethAmount" size="50" value="Eth Amount" onfocus="this.value=''">
					</td>
				</tr>
					<td align="center" colspan="10">
						<input type="submit" name = "addEth" value="Add"/>
						<input type="submit" name ="removeEth" value="Remove"/>
						</form>
					</td>
				</tr>
				</table>
				
	</div>
		 </center>
		 </div>
	</body>
</html>