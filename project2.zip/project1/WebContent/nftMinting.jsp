<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %> 
    
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Mint an NFT</title>
</head>

<center><h1>Enter the details to mint your NFT</h1> </center>
<center><a href="activitypage.jsp"target ="_self" > back to homepage</a><br><br> </center>
 
	<body>
	<div align="center">
		<p> ${errorOne } </p>
		<p> ${errorTwo } </p>
		<form action="mint">
			<table border="1" cellpadding="5">
				<tr>
					<th>Name: </th>
					<td align="center" colspan="3">
						<input type="text" name="name" size="30"  value="NFT Name" onfocus="this.value=''">
					</td>
				</tr>
				<tr>
					<th>Description: </th>
					<td align="center" colspan="3">
						<input type="text" name="description" size="70" value="NFT Description" onfocus="this.value=''">
					</td>
				</tr>
				<tr>
					<th>Image url: </th>
					<td align="center" colspan="3">
						<input type="text" name="imagePath" size="70" value="NFT URL" onfocus="this.value=''">
					</td>
				</tr>
				<tr>
						<td align="center" colspan="5">
						<input type="submit" value="Mint"/>
					</td>
				</tr>
			</table>
		</form>
	</div>
</html>