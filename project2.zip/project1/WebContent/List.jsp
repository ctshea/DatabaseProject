<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %> 
    
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Listing page</title>
</head>
<center><h1>List an NFT</h1> </center>
<div align="center">
	<body>
	 <center>
		 <a href="activitypage.jsp?"target ="_self" > Back to Homepage</a><br><br> 
    	<div align="center">
    	<form action="listing">
    	<input type="hidden" name="nftname" value="<%= request.getParameter("nftname") %>">
    	<table border="1" cellpadding="6">
    	    <caption><h2>Enter time duration and amount to list <%= request.getParameter("nftname") %> for.</h2></caption>
    	    		<p> ${errorOne } </p>
    	    		<p> ${errorTwo } </p>
    	    		<p> ${errorThree } </p>
            <tr>
					<th>Duration(days): </th>
					<td align="center" colspan="3">
						<input type="text" name="Duration" size="50" value="Duration" onfocus="this.value=''">
					</td>
				</tr>
				            <tr>
					<th>Amount(eth): </th>
					<td align="center" colspan="3">
						<input type="text" name="Amount" size="50" value="Amount" onfocus="this.value=''">
					</td>
				</tr>
					<tr>
					<td align="center" colspan="5">
						<input type="submit" value="List"/>
					</td>
				</tr>
				</table>
				</form>
	</div>
		 </center>
		 </div>
	</body>
</html>