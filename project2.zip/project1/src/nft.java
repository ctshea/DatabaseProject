public class nft 
{
		protected int nftid;
		protected String name;
	    protected String description;
	    protected String image;
	    protected String userEmail;
	    protected String listed;
	 
	    //constructors
	    public nft() {
	    }
	 
	
	    public nft(String name, String description, String image,String userEmail, String listed) 
	    {
	    	this.name = name;
	    	this.description = description;
	    	this.image = image;
	    	this.userEmail = userEmail;
	    	this.listed = listed;
	    }
	    public nft(int ID, String name, String description, String image,String userEmail, String listed) 
	    {
	    	this.nftid = ID;
	    	this.name = name;
	    	this.description = description;
	    	this.image = image;
	    	this.userEmail = userEmail;
	    	this.listed = listed;
	    }
	    
	   //getter and setter methods
	 	public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		public String getImage() {
			return image;
		}

		public void setImage(String image) {
			this.image = image;
		}

		public String getUserEmail() {
			return userEmail;
		}

		public void setUserEmail(String userEmail) {
			this.userEmail = userEmail;
		}
		public int getNftid( ) {
			return nftid;
		}
		public void setListed(String listed) {
			this.listed = listed;
		}
		public String getListed() {
			return listed;
		}
	}