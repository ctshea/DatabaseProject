import java.math.BigDecimal;

public class listings 
{
		protected int listingsid;
		protected int nftid;
		protected int duration;
	    protected String dateListed;
	    protected BigDecimal cost;
	    protected String activeState;
	    
	    protected String nftName;			//strictly for output purposes
	    protected int daysRemaining;		//strictly for output purposes
	    protected String description;		//strictly for output purposes
	    protected String imagePath;			//strictly for output purposes
	    protected String seller;			//strictly for output purposes
	 
	    //constructors
	    public listings() {
	    }

	    public listings(int nftId, String nftname, int duration, int daysRemaining,BigDecimal cost) 
	    {
	    	this.nftid = nftId;
	    	this.duration = duration;
	    	this.daysRemaining = daysRemaining;
	    	this.cost = cost;
	    	this.nftName = nftname;
	    }
	    
	    public listings(int listingsid, int nftId, String nftname,String description, String imagePath, int duration, int daysRemaining,BigDecimal cost, String seller) 	//for outputting active listings
	    {
	    	this.listingsid = listingsid;
	    	this.nftid = nftId;
	    	this.nftName = nftname;
	    	this.description = description;
	    	this.imagePath = imagePath;
	    	this.duration = duration;
	    	this.daysRemaining = daysRemaining;
	    	this.cost = cost;
	    	this.seller = seller;
	    }
	    
	    public listings(int nftId, int duration, String date,BigDecimal cost, String active) 
	    {
	    	this.nftid = nftId;
	    	this.duration = duration;
	    	this.dateListed = date;
	    	this.cost = cost;
	    	this.activeState = active;
	    }
	    
	    public listings(int ID, int nftId, int duration, String date,BigDecimal cost, String active) 
	    {
	    	this.listingsid = ID;
	    	this.nftid = nftId;
	    	this.duration = duration;
	    	this.dateListed = date;
	    	this.cost = cost;
	    	this.activeState = active;
	    }
	    
	   //getter and setter methods
		public int getNftid() {
			return nftid;
		}
		public void setNftid(int nftid) {
			this.nftid = nftid;
		}
		public int getDuration() {
			return duration;
		}
		public void setDuration(int duration) {
			this.duration = duration;
		}
		public String getDateListed() {
			return dateListed;
		}
		public void setDateListed(String dateListed) {
			this.dateListed = dateListed;
		}
		public BigDecimal getCost() {
			return cost;
		}
		public void setCost(BigDecimal cost) {
			this.cost = cost;
		}
		public String getActiveState() {
			return activeState;
		}
		public void setActiveState(String activeState) {
			this.activeState = activeState;
		}
		public int getListingsid() {
			return listingsid;
		}
		
		public String getNftName() {
			return nftName;
		}
		
		public int getDaysRemaining() {
			return daysRemaining;
		}
		public String getDescription() {
			return description;
		}
		public String getImagePath() {
			return imagePath;
		}
		public String getSeller() {
			return seller;
		}
	}