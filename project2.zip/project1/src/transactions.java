public class transactions 
{
		protected int transactionid;
		protected String userIdBuyer;
		protected String userIdSeller;
	    protected String dateCompleted;
	    protected String type;
	    protected int nftid;
	    protected String listingsid;	//listingsId can be null -> if NFT was directly transferred
	    	//String so that we can show '-' for null values on the table.
	 
	    //constructors
	    public transactions() {
	    }

	    public transactions(String buyer, String seller, String date,String type, int nftId, String listingsid) 
	    {
	    	this.userIdBuyer= buyer;
	    	this.userIdSeller = seller;
	    	this.dateCompleted = date;
	    	this.type = type;
	    	this.nftid = nftId;
	    	this.listingsid = listingsid;
	    }
	    
	    public transactions(int ID, String buyer, String seller, String date,String type, int nftId, String listingsid) 
	    {
	    	this.transactionid = ID;
	    	this.userIdBuyer= buyer;
	    	this.userIdSeller = seller;
	    	this.dateCompleted = date;
	    	this.type = type;
	    	this.nftid = nftId;
	    	this.listingsid = listingsid;
	    }

	    
	   //getter and setter methods
	    public String getUserIdBuyer() {
			return userIdBuyer;
		}
		public void setUserIdBuyer(String userIdBuyer) {
			this.userIdBuyer = userIdBuyer;
		}
		public String getUserIdSeller() {
			return userIdSeller;
		}
		public void setUserIdSeller(String userIdSeller) {
			this.userIdSeller = userIdSeller;
		}
		public String getDateCompleted() {
			return dateCompleted;
		}
		public void setDateCompleted(String dateCompleted) {
			this.dateCompleted = dateCompleted;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
		public int getNftid() {
			return nftid;
		}
		public void setNftid(int nftid) {
			this.nftid = nftid;
		}
		public String getListingsid() {
			return listingsid;
		}
		public void setListingsid(String listingsid) {
			this.listingsid = listingsid;
		}
		public int getTransactionid() {
			return transactionid;
		}
	}